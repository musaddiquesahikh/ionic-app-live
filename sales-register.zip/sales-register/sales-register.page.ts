import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { AlertController, ModalController, ToastController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { ApiService } from '../api.service';
import { EditBillPage } from '../edit-bill/edit-bill.page';
import { PermissionGuard } from '../guards/permission.guard';


@Component({
  selector: 'app-sales-register',
  templateUrl: './sales-register.page.html',
  styleUrls: ['./sales-register.page.scss'],
})
export class SalesRegisterPage implements OnInit {
  sales: any[];
  company: any = []
  item: any = {}
  companyId: any;
  salesData: any = []
  selected_invoice: any = []
  length: any
  isItemAvailable: boolean = false;
  numbers: any;
  items: any;
 


  constructor(private router: Router, public modalCtrl: ModalController, public api: ApiService, public toastController: ToastController,
    private translate: TranslateService, public permission: PermissionGuard, public alertCtrl: AlertController) { }

  ngOnInit() {
 
    this.api.defaultDate().subscribe((response: any[]) => {
      console.log(response);
      this.item = response
    });
  }

  myBackButton() {
    this.modalCtrl.dismiss();
  }
  submit() {
    this.companyId = this.api.getCompanyId()
    this.item.companyId = this.companyId
    console.log("companyId", this.companyId);
    let header = this.api.getHeader();
    this.api.salesRegister(this.item, header).subscribe(async (response: any) => {
      if (response.status == 200) {
        this.salesData = response.data
        console.log("lenght", response);
        this.length = response.data.length
        console.log("lenght", this.salesData);

        if (this.length == 0) {
          const toast = await this.toastController.create({
            message: this.translate.instant('HEADER.NO DATA AVAILABLE'),
            duration: 3000,
            color: "warning"
          });
          toast.present();
        }
      }
    });
   console.log();
  }
  async selected(selected_invoice) {
    console.log("asd");
    console.log(selected_invoice);
    const modal = await this.modalCtrl.create({
      
      component: EditBillPage,
      cssClass: 'my-custom-class',
      componentProps: {
        billData: selected_invoice,
        open:true
      },
      // breakpoints: [0, 0.3, 0.5, 1],
      // initialBreakpoint: 1
    });
    modal.onWillDismiss()
        .then((data: any = {}) => {
        const user = data.data; // Here's your selected user!
        console.log("from address 123 ", user)
        // this.getparty();
        this.submit()
      });
    return await modal.present();
  }

  excel() {
    let companyId = this.api.getCompanyId()
    this.item.company = companyId
    console.log("companyId", companyId);
    let header = this.api.getHeader();
    this.api.exportSalesRegister(this.item, header).subscribe((response: any) => {
      console.log("dsafdsdsafas", response);
      if (response.status != 500) {
        window.location.href = response.url
      }
    });
  }
  async deleteInvoice(item) {
    for (let hh of this.permission.roles.data.permissions) {
      console.log("asd");
      if (hh.page_name == 'sales_voucher') {
        console.log("asd123", hh.actions.delete);
        if (hh.actions.delete == true) {
          console.log(item);
          const toast = await this.toastController.create({
            header: this.translate.instant('MESSAGE.ARE YOU SURE YOU WANT TO DELETE THE INVOICE?'),
            position: "bottom",
            buttons: [
              {
                text: this.translate.instant('HEADER.YES'),
                role: "done",
                handler: () => {
                  let header = this.api.getHeader();
                  let company = this.api.getCompanyId()
                  let data = { id: item, company: company }
                  console.log("this.item", item);
                  this.api.deleteInvoice(data, header).subscribe(async (response: any) => {
                    console.log(response, 'delete party');
                    let a = response.msg
                    const toast = await this.toastController.create({
                      message: a,
                      duration: 2000,
                      color: "warning"
                    });
                    toast.present();
                    this.submit()
                    // this.getparty();
                  },
                    async (error) => {
                      console.log("pppp", error);

                      const toast = await this.toastController.create({
                        message: error,
                        duration: 2000,
                        color: "danger"
                      });
                      toast.present();
                      this.submit()
                    })
                },
              },
              {
                text: this.translate.instant('HEADER.CANCEL'),
                role: "cancel",
              },
            ],
          });
          toast.present();
        }
        else {
          let alert = await this.alertCtrl.create({
            header: this.translate.instant('MESSAGE.UNAUTHORIZED'),
            message: this.translate.instant('MESSAGE.YOU ARE NOT AUTHORIZED TO VISIT THAT PAGE'),
            buttons: ['OK']
          });
          alert.present();
          this.modalCtrl.dismiss();
        }
      }
    }
  }

  getSales(e: any) {
    console.log(e.target.value)
    const val = e.target.value;
    if (val && val.trim() !== '') {
      this.salesData = this.salesData.filter((item) => {
        return (item.invoice_no.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
    else {
      this.submit()
    }
  }

}
