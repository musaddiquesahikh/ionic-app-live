import { EWayPage } from './../e-way/e-way.page';
import { InvoiceSettingPage } from './../invoice-setting/invoice-setting.page';
import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController, NavController, ToastController } from '@ionic/angular';
import { modalController } from '@ionic/core';
import { TranslateService } from '@ngx-translate/core';
import { ApiService } from '../api.service';
import { PermissionGuard } from '../guards/permission.guard';
import { Subscription } from 'rxjs';
// import { log } from 'console';
import * as html2pdf from 'html2pdf.js';
import { response } from 'express';
import { jsPDF } from 'jspdf';

@Component({
  selector: 'app-invoice-beta',
  templateUrl: './invoice-beta.page.html',
  styleUrls: ['./invoice-beta.page.scss'],
})

export class InvoiceBetaPage implements OnInit {
  @ViewChild('segment') segment: any; company: any = {};
  @Input() invoice_type1
  exp1: any = []
  toggleItem: boolean = true
  prefix: boolean
  invoiceID: any
  exp: any = []
  invoice_type = 1;
  poNo: boolean
  addF: boolean
  vehicleNo: boolean
  ewayNo: boolean
  subTotal: number
  total_amount: number
  received_amt: number
  discountTotal: number
  addCharge: boolean
  invoice_model: any = {
    invoice_no: "",
    invoice_date: "",
    payment_terms: 30,
    due_date: "",
    total_amount: 0,
    discount: 0,
    discountTotal: 0,
    received_amt: 0,
    receivable: 0,
    partial_paid: 0,
    party: 0,
    taxable_amount: 0,
    invoice_type: 1,
    payment_status: 1,
    company_name: 14,
    extra_fields: [],
    extra_charges_lst: [],
    extraCharged: 0,
    items: [{
      units: []
    }],
    place_of_supply: 1,
  }
  invSett: any = []
  dictionary: any = [{
    "type": "1",
    "header": this.translate.instant('HEADER.SALES INVOICE'),
    "label": this.translate.instant('HEADER.SALES INVOICE NO'),
    "sButton": this.translate.instant('HEADER.SAVE INVOICE'),
    "gButton": "Generate Bill"
  },
  {
    "type": "2",
    "header": this.translate.instant('HEADER.PURCHASE INVOICE'),
    "label": this.translate.instant('HEADER.PURCHASE INVOICE NO'),
    "sButton": this.translate.instant('HEADER.SAVE PURCHASE INVOICE'),
    "gButton": "Generate Bill"

  },
  {
    "type": "3",
    "header": this.translate.instant('HEADER.RECORD SALES RETURN'),
    "label": "Credit Note No",
    "sButton": this.translate.instant('HEADER.SAVE SALES RETURN'),
    "gButton": "Save & New"
  },
  {
    "type": "4",
    "header": this.translate.instant('HEADER.RECORD PURCHASE RETURN'),
    "label": "Debit Note No",
    "sButton": this.translate.instant('HEADER.SAVE PURCHASE RETURN'),
    "gButton": "Save & New"
  },
  {
    "type": "5",
    "header": this.translate.instant('HEADER.CREATE QUOTATION'),
    "label": this.translate.instant('HEADER.QUOTATION NO'),
    "sButton": this.translate.instant('HEADER.SAVE QUOTATION'),
    "gButton": "Save & New"
  },
  {
    "type": "6",
    "header": this.translate.instant('HEADER.CREATE DELIVERY CHALLAN'),
    "label": this.translate.instant('HEADER.CHALLAN NO'),
    "sButton": this.translate.instant('HEADER.SAVE CHALLAN'),
    "gButton": "Save & New"
  },
  {
    "type": "7",
    "header": this.translate.instant('HEADER.PROFORMA INVOICE'),
    "label": this.translate.instant('HEADER.INVOICE NO'),
    "sButton": this.translate.instant('HEADER.SAVE PROFORMA'),
    "gButton": "Save & New"
  },]

  showItemsPanel: Boolean = false

  providers: [DatePipe]

  items: any = []
  partyComponent: boolean = false;
  itemComponent: boolean = false;
  party_details: any = {};
  placeOf: any;
  total_taxable_amount: number;
  total_cess_rate: number;
  company_gst: any;
  totaltax: number;
  cgst: number = 0;
  sgst: number = 0;
  igst: number = 0;
  finalItem: any = [];
  submit: boolean;
  billId: any;
  downloadUrl: string;
  bank: any = [];
  finalAmount: number;
  noTax: Boolean = true;
  invoiceD: any;
  merchanTrans_id: any;
  payentStatusPOS: any = {};
  statusbutton: boolean = false;
  paymentDone: boolean = false;
  progressWheel: boolean = false;
  resendbutton: Boolean = false;
  itemEmitted: any;
  units: any;
  unit: any;
  u: any;
  toast: any;
  place: any;
  gst: boolean = false;
  place_of_supply: any;
  extraF: any = [];
  showInvoice: boolean;
  get: number;
  enableEInvoice: boolean ;
  companyDetails: any;
  eInvoice: Boolean = false;
  warningParty: boolean;
  eWayBill: boolean = false;
  e = {};
  ewaybillDownload: boolean = false;
  vehicleDetails: boolean = false;
  vehicleSubmitted: any;
  sales_prices: number

  selectSegment = 'a';
  // a: boolean=true;
  // b: boolean=false;
  downloadEinvoiceButton: boolean = false;
  toggleitem: Boolean = true;
  partialPAid: number;
  receivable: number;
  charge: any;
  downloadEinvoicePDF1: string;
  downloadEwaybill: string;

  round_off: boolean = false;
  gstData: any = [];
  name: any = [];
  p: any;
  multiple: any = [{
    from_rate: 0,
    to_rate: 0,
    tax: ""

  }]
  private navigationEndSubscription: Subscription;



  on_tour: boolean = true
  einvoiceErrorInfo: any;
  einvoiceErrorInfoShow: boolean;
  enableEwayBill: boolean;
  ePost: any;
  constructor(private cdr: ChangeDetectorRef, public api: ApiService, public datepipe: DatePipe, public toastController: ToastController, public router: Router,
    public modal: ModalController, private translate: TranslateService, private permission: PermissionGuard, private alertCtrl: AlertController,
    public location: Location, private navCtrl: NavController) { }

  ngOnInit() {
    this.getGSTrate()
    console.log(JSON.parse(sessionStorage.getItem("currentCompany")), "compp")
    this.invoice_head()
    this.partialPAid = 0;
    this.addCharge = false
    this.poNo = false
    this.ewayNo = false
    this.vehicleNo = false
    this.addF = false
    this.prefix = false
    this.invoice_model.received_amt = 0;
    this.total_amount = 0
    this.subTotal = 0;
    this.receivable = 0;
    this.invoice_model.discountTotal = 0
    this.invoice_model.extraCharged = 0;
    this.supply()
    console.log(this.companyDetails, "p");
    this.invoice_model.round_off = false

    // console.log(this.companyDetails[0].pay_gateway_service);

    this.companyDetails = JSON.parse(sessionStorage.getItem('currentCompany'));
    // this.deleteLedger(i)


    let companyDetails = JSON.parse(sessionStorage.getItem("currentCompany"))
    if (companyDetails[0].einvoice_service == true) {
      console.log(this.eInvoice, "eeeeeeeeeeeeee",companyDetails[0].einvoice_service );

    }
    if (this.companyDetails[0].ewb_service == true) {
      this.enableEwayBill = true;
    }
    if (this.companyDetails[0].einvoice_service == true) {
      this.enableEInvoice = true;
    }
    else{
      this.enableEInvoice = false;

    }

  }

  ngOnDestroy() {
    if (this.navigationEndSubscription) {
      this.navigationEndSubscription.unsubscribe();
    }
  }


  invoice_head() {
    console.log("call function");

    this.invoice_type = this.invoice_type1
    console.log(this.invoice_type, "prajakta");


    let companyDetails = JSON.parse(sessionStorage.getItem("currentCompany"))
    if (companyDetails[0].einvoice_service == true) {
      this.enableEInvoice = true;

    }
    this.companyDetails = JSON.parse(sessionStorage.getItem("currentCompany"));
    if (this.companyDetails[0].einvoice_service == true) {
      this.enableEInvoice = true;
    }
    this.company_gst = this.companyDetails[0].gst_number
    let companyId = this.api.getCompanyId()
    let header = this.api.getHeader()
    this.invoice_model.invoice_type = this.invoice_type
    if (this.invoice_type == 1 || this.invoice_type == 3) {
      this.api.getInvoiceNo(companyId, header).subscribe((response: any) => {
        console.log(response, "prefix");

        if (response.status != 500) {
          // this.invoice_model.invoice_no = response.sales_invoice_no;
          this.invoice_model.invoice_no = response.invoice_settings.prefix + response.sales_invoice_no + response.invoice_settings.suffix;

        }
      })
    }
    let company = this.api.getCompanyId()
    let a = this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 4 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7;
    if (this.invoice_type == 1) {
      this.api.post3('get_invoice_settings/', { "company": company, "type": Number(a) }).subscribe((response: any) => {
        this.invSett = response
        this.invSett.extra_fields = JSON.parse(response.extra_fields)

        console.log(response, 'setting');
      })
    }
    this.api.bankList(companyId, header).subscribe((response: any) => {
      if (response.status != 500) {
        this.bank = response
      }
    });
    let term = this.invoice_type;
    this.dictionary = this.dictionary.filter((dictionary) => {
      return dictionary.type.indexOf(term) > -1;
    });
    let today_date = Date.now();
    this.invoice_model.invoice_date = today_date
    this.dateChange()
  }
  invoiceSFunction(sett: any) {
    this.invSett = sett
    this.invoice_head()
  }

  getInvoiceSetting() {
    let company = this.api.getCompanyId()
    this.api.post3('get_invoice_settings/', { "company": company, "type": Number(this.invoice_type) }).subscribe((response: any) => {
      // console.log("response on invoice setting", response);

    })
  }
  dateChange() {
    // this.invoice_model.due_date = new Date(Date.now() + this.invoice_model.payment_terms * 24 * 60 * 60 * 1000)
    // this.invoice_model.invoice_date = this.datepipe.transform(this.invoice_model.invoice_date, 'yyyy-MM-dd')
    // this.invoice_model.due_date = this.datepipe.transform(this.invoice_model.due_date, 'yyyy-MM-dd')

    this.invoice_model.invoice_date = this.datepipe.transform(this.invoice_model.invoice_date, 'yyyy-MM-dd')
    var nextDay = new Date(this.datepipe.transform(this.invoice_model.invoice_date, 'yyyy-MM-dd'));
    nextDay.setDate(nextDay.getDate() + Number(this.invoice_model.payment_terms));
    this.invoice_model.due_date = this.datepipe.transform(nextDay, 'yyyy-MM-dd')
  }

  showPartyData() {
    this.partyComponent = true;
    if (this.partyComponent) {
      this.gst = true
    }
    else {
      this.gst = false
    }
  }
  showItemData() {
    this.itemComponent = true;
  }
  dismiss(index) {
    this.items.splice(index, 1);
    this.calculation()
  }
  async partyFunction(party: any) {
    console.log(party, "party");
    console.log(this.enableEInvoice,);

    if (party.c_party == false) {
      console.log("hide party");
      this.partyComponent = false;
    }
    this.party_details = party
    if (this.party_details.gstin == null) {
      // console.log(this.party_details,"sheeeetal");

      this.placeOf = this.party_details.gst_compare
      this.placeOf = this.placeOf.slice(0, 2)
      console.log(this.enableEInvoice,);
      if (this.enableEInvoice == true) {
        // alert(this.party_details.Party_name + " " + this.translate.instant("MESSAGE.DOES NOT HAVE GSTIN")),
        // this.eInvoice = false
      }
    } else {
      this.placeOf = this.party_details.gstin.slice(0, 2)
    }
    this.partyComponent = false
    this.showItemsPanel = true

    this.submit = true
    this.placeOf = this.party_details.gst_compare
    this.invoice_model.place_of_supply = Number(this.placeOf)
    if (this.invoice_model.place_of_supply < 10) {
      this.placeOf = "0" + this.invoice_model.place_of_supply.toString()
      console.log(this.placeOf, "ppppppp");
    }
    else {
      this.placeOf = this.invoice_model.place_of_supply.toString()
    }
    console.log(this.invoice_model.place_of_supply, "ppppppp");
    if (this.party_details.gstin != null) {
      console.log(this.eInvoice, "eInvoice");
      let f = JSON.parse(sessionStorage.getItem("currentCompany"))
      console.log(f);
      if (f[0].einvoice_service == true) {
        if (this.eInvoice == false) {
          console.log(this.eInvoice, "eInvoice");
        }
      }
    }
    else {
      if (this.enableEInvoice == true) {
        if (this.invoice_type==1) {
        const toast = await this.toastController.create({
          message: party.Party_name + " " + this.translate.instant("MESSAGE.DOES NOT HAVE GSTIN"),
          duration: 3000,
          color: "warning"
        });
        toast.present();
        this.eInvoice = false
      }
    }
    }
    this.calculation();
    this.calculateTax();
    this.calculateGst();
  }

  parentFunction1(data1: any) {
    console.log(data1, 'from parent');
    let data = Object.assign([], data1)
    for (let m of data) {
      m.length_c = 1
      m.breadth = 1
    }
    if (this.toggleItem) {
      let index = this.items.findIndex((item: any) => data.some((d: any) => d.id === item.id));
      const indices: number[] = this.items.reduce((acc: number[], item: any, index: number) => {
        if (data.some((d: any) => d.id === item.id)) {
          acc.push(index);
        }
        return acc;
      }, []);
      console.log('show quantity', indices);
      if (indices.length !== 0) {
        for (let pt of indices) {
          if (pt > -1) {
            if (this.items[pt].item_type === 1) {
              this.items[pt].quantity = this.items[pt].quantity + 1;
            }
          }
        }
      }
      const unmatchedData = data.filter((d: any) => !this.items.some((item: any) => item.id === d.id));
      this.items = this.items.concat(unmatchedData);
    } else {
      this.items = this.items.concat(data);
    }
    data.x_idfor = data.tax_rate_id
    if (data.c_party == undefined) {
      if (data.discount == null) {
        data.discount = 0;
      }

      if (data.c_party == false) {
        console.log("hide party");
        this.itemComponent = false;
      }
      // this.items = this.items.concat(data);
      console.log(this.items)
      this.itemComponent = false
    }
    this.itemEmitted = data
    console.log(this.itemEmitted, 'emitted items');

    for (let t of this.items) {
      // this.subTotal = t.sales_prices

      if (t.item_type == 1) {
        console.log(t.units, "units");
        if (t.units.length > 0) {
          console.log('inside if');
          let i = 0
          this.unit = this.items[i].units
          for (let s of t.units) {

            t.units[i].unit = t.units[i].unit.slice(0, 3)

            t.abc = t.units[0]
            i++;
            console.log(s.type);

          }
        }
        else {

          t.abc = { id: null, type: null, unit: null }
          console.log('inside else');

        }
      }
      else {
        t.abc = { id: null, type: null, unit: null }
      }

    }
    // console.log(data,"data");



    this.subTotal = this.total();
    this.total_taxable_amount = this.total_taxable();
    this.calculateTax()
    this.calculation();
    console.log(this.itemEmitted, 'after emit');

    let index = this.itemEmitted.findIndex((item) => item)
    console.log(index, this.items.length, 'index of emitted');

    if (this.itemEmitted[0].multiple_rates) {
      this.selectgstrate(this.itemEmitted[0], this.items.length - 1)

    }

  }
  unitChange(unit: any, i: any) {
    console.log(unit.type, "praj");
    if (unit.type == 1) {
      this.items[i].oldRate = this.items[i].rate;
      this.items[i].oldPurchaseRate = this.items[i].purchase_rate;
      this.items[i].rate = this.items[i].conversion_rate_sales;
      this.items[i].purchase_rate = this.items[i].conversion_rate_purchase;
    } else {
      this.items[i].rate = this.items[i].oldRate;
      this.items[i].purchase_rate = this.items[i].oldPurchaseRate;
    }
    this.calculation();
  }
  calculation() {
    let index = 0;
    for (let i of this.items) {
      if (i.Gst_tax_rate == -1) {

        this.items[index].sales_prices = (i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate)) + ((0 + i.cess_tax_rate) / 100 * ((i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate))))
        this.items[index].sales_prices = Math.round((this.items[index].sales_prices + Number.EPSILON) * 100) / 100
        this.items[index].purchase_prices = (i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate)) + ((0 + i.cess_tax_rate) / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
        this.items[index].purchase_prices = Math.round((this.items[index].purchase_prices + Number.EPSILON) * 100) / 100
      } else {
        this.items[index].sales_prices = (i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate)) + ((i.Gst_tax_rate + i.cess_tax_rate) / 100 * ((i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate))))
        this.items[index].sales_prices = Math.round((this.items[index].sales_prices + Number.EPSILON) * 100) / 100
        this.items[index].purchase_prices = (i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate)) + ((i.Gst_tax_rate + i.cess_tax_rate) / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
        this.items[index].purchase_prices = Math.round((this.items[index].purchase_prices + Number.EPSILON) * 100) / 100
      }
      this.items[index].cess = ((i.cess_tax_rate / 100 * ((i.rate * i.quantity) - (i.discount / 100 * (i.quantity * i.rate)))))
      if (i.Gst_tax_rate == -1) {
        this.items[index].sales_tax = 0
        this.items[index].purchase_tax = 0
      } else {
        this.items[index].sales_tax = (i.Gst_tax_rate / 100 * ((i.rate * i.quantity) - (i.discount / 100 * (i.quantity * i.rate))))
        this.items[index].purchase_tax = (i.Gst_tax_rate / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
      }

      this.items[index].cessp = (i.cess_tax_rate / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
      index++
    }

    this.total_taxable_amount = Math.round((this.total_taxable() + Number.EPSILON) * 100) / 100
    // this.total_amount = Math.round(this.total() - ((this.invoice_model.discountTotal * this.total()) / 100) + Number.EPSILON)
    if (this.round_off) {
      this.subTotal = Math.round((this.subTotal))

    }
    else {
      // this.subTotal = Math.round((((this.subTotal + Number(this.invoice_model.extraCharged))) + Number.EPSILON) * 100) / 100
      this.subTotal = (Math.round((((this.total() - (((this.invoice_model.discountTotal) * this.total()) / 100))) + Number.EPSILON) * 100) / 100)
      this.subTotal = Math.round((((this.subTotal + Number(this.invoice_model.extraCharged))) + Number.EPSILON) * 100) / 100

    }

    console.log(this.invoice_model.discountTotal, this.subTotal, this.total_amount, this.invoice_model.extraCharged, "receivable");

    this.totaltax = Math.round((this.calculateTax() + Number.EPSILON) * 100) / 100
    this.calculateGst()
    this.receivable = Math.round((((this.subTotal - this.invoice_model.received_amt)) + Number.EPSILON) * 100) / 100
    console.log(this.items, "after calculationreceivable");
    this.total_cess()
  }
  revCal() {
    let index = 0;
    for (let i of this.items) {
      if (i.Gst_tax_rate == -1) {
        i.rate = this.items[index].sales_prices / (i.quantity * (1 - (i.discount / 100) + ((0 + i.cess_tax_rate) / 100 - (i.discount / 100) * ((0 + i.cess_tax_rate) / 100))))
        i.rate = Math.round((i.rate + Number.EPSILON) * 100) / 100
        i.purchase_rate = this.items[index].purchase_prices / (i.quantity * (1 - (i.discount / 100) + ((0 + i.cess_tax_rate) / 100 - (i.discount / 100) * ((0 + i.cess_tax_rate) / 100))))
        i.purchase_rate = Math.round(i.purchase_rate)
      } else {
        i.rate = this.items[index].sales_prices / (i.quantity * (1 - (i.discount / 100) + ((i.Gst_tax_rate + i.cess_tax_rate) / 100 - (i.discount / 100) * ((i.Gst_tax_rate + i.cess_tax_rate) / 100))))
        i.rate = Math.round((i.rate + Number.EPSILON) * 100) / 100
        i.purchase_rate = this.items[index].purchase_prices / (i.quantity * (1 - (i.discount / 100) + ((i.Gst_tax_rate + i.cess_tax_rate) / 100 - (i.discount / 100) * ((i.Gst_tax_rate + i.cess_tax_rate) / 100))))
        i.purchase_rate = Math.round(i.purchase_rate)
      }
      this.items[index].cess = ((i.cess_tax_rate / 100 * ((i.rate * i.quantity) - (i.discount / 100 * (i.quantity * i.rate)))))
      if (i.Gst_tax_rate == -1) {
        this.items[index].tax = 0
        this.items[index].taxp = 0
      } else {
        this.items[index].tax = (i.Gst_tax_rate / 100 * ((i.rate * i.quantity) - (i.discount / 100 * (i.quantity * i.rate))))
        this.items[index].taxp = (i.Gst_tax_rate / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
      }
      this.items[index].cessp = (i.cess_tax_rate / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
      console.log(i.rate, 'reverse cal');

      index++
    }


    this.total_taxable_amount = Math.round((this.total_taxable() + Number.EPSILON) * 100) / 100
    // this.total_amount = Math.round(this.total() - ((this.invoice_model.discountTotal * this.total()) / 100) + Number.EPSILON)
    if (this.round_off) {
      this.subTotal = Math.round((this.subTotal))

    }
    else {
      // this.subTotal = Math.round((((this.subTotal + Number(this.invoice_model.extraCharged))) + Number.EPSILON) * 100) / 100
      this.subTotal = (Math.round((((this.total() - (((this.invoice_model.discountTotal) * this.total()) / 100))) + Number.EPSILON) * 100) / 100)
      this.subTotal = Math.round((((this.subTotal + Number(this.invoice_model.extraCharged))) + Number.EPSILON) * 100) / 100

    }

    console.log(this.invoice_model.discountTotal, this.subTotal, this.total_amount, this.invoice_model.extraCharged, "receivable");

    this.totaltax = Math.round((this.calculateTax() + Number.EPSILON) * 100) / 100
    this.calculateGst()
    this.receivable = Math.round((((this.subTotal - this.invoice_model.received_amt)) + Number.EPSILON) * 100) / 100
    console.log(this.invoice_model.received_amt, "receivable");
    this.total_cess()

  }
  roundOff() {
    this.round_off = !this.round_off
    this.calculation()
  }

  total_taxable() {
    let ff = 0;
    let tt = 0;
    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = ((((value.rate * value.quantity) - (value.discount / 100 * (value.quantity * value.rate))) + ff));
      });
    }
    else {
      this.items.forEach(function (value) {
        ff = ((((Number(value.purchase_rate) * value.quantity) - (value.discount / 100 * (value.quantity * Number(value.purchase_rate)))) + ff));
      });
    }
    this.total_taxable_amount = ff;
    return ff;
  }
  total() {
    let ff = 0;
    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = (value.sales_prices) + ff;

      });
    }
    else {
      this.items.forEach(function (value) {
        ff = (value.purchase_prices) + ff;
      });
    }
    this.subTotal = ff;

    return ff;
  }

  total_cess() {
    let ff = 0;

    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = (value.cess_tax + ff);
      });
    }
    else {
      this.items.forEach(function (value) {
        ff = (value.cessp + ff);
      });
    }
    this.total_cess_rate = ff
    return ff;
  }

  calculateGst() {
    console.log("company gst", this.company_gst);

    if (this.company_gst == null) {
      this.noTax = false

    } else if (this.company_gst == "") {
      this.noTax = false
    }
    if (this.company_gst) {
      this.company_gst = this.company_gst.slice(0, 2)
      this.noTax = true
    }
    console.log("party gst", this.placeOf);

    if (this.placeOf == this.company_gst) {
      if (this.company_gst !== null) {

        this.cgst = this.totaltax / 2
        this.sgst = this.totaltax / 2
        this.igst = 0

      } else {
        this.cgst = 0
        this.sgst = 0
        this.igst = 0
        // this.igst = this.totaltax
      }
    }
    if (this.placeOf !== this.company_gst) {
      console.log(this.placeOf, "not equal");

      if (this.company_gst !== null) {
        this.igst = this.totaltax
        this.cgst = 0
        this.sgst = 0
      }
      else {
        this.cgst = 0
        this.sgst = 0
        this.igst = 0
      }
    }
  }
  calculateTax() {
    let ff = 0;
    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = value.sales_tax + ff;
      });
    }
    else {
      // console.log('total cal for pur');
      this.items.forEach(function (value) {
        ff = value.purchase_tax + ff;
      });
    }
    this.totaltax = ff;
    // console.log("dsfads", ff)
    return ff;

  }
  putinarray() {

    for (let i of this.items) {
      console.log("mmmmaaaaa", this.items);

      if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
        if (i.Gst_tax_rate == -1) {

          console.log("put if running", this.items);

          this.finalItem.push({
            unit: i.units.id,
            unit_type: i.abc.type,
            items: i.id,
            quantity: i.quantity,
            discount: Number(i.discount),
            rate: Number(i.rate),
            total_amount: i.sales_prices,
            tax_percent: i.Gst_tax_rate,
            tax_amount: i.sales_tax,
            cess: i.cess_tax_rate,
            cess_amount: i.cess,
            tax_rate_id: i.tax_rate_id,
            cess_rate_id: i.cess_tax_rate_id,
            lxb: { length_c: Number(i.length_c), breadth: Number(i.breadth) }
          });
        }
        else {
          console.log("put else running");

          this.finalItem.push({
            unit: i.abc.id,
            unit_type: i.abc.type,
            items: i.id,
            quantity: i.quantity,
            discount: Number(i.discount),
            rate: Number(i.rate),
            total_amount: i.sales_prices,
            tax_percent: i.Gst_tax_rate,
            tax_amount: i.sales_tax,
            cess: i.cess_tax_rate,
            cess_amount: i.cess,
            tax_rate_id: i.tax_rate_id,
            cess_rate_id: i.cess_tax_rate_id,
            lxb: { length_c: Number(i.length_c), breadth: Number(i.breadth) }
          });

        }
      }
      else {
        this.finalItem.push({
          unit: i.abc.id,
          unit_type: i.abc.type,
          items: i.id,
          quantity: i.quantity,
          discount: Number(i.discount),
          rate: Number(i.purchase_rate),
          total_amount: i.purchase_prices,
          tax_percent: i.Gst_tax_rate,
          tax_amount: i.purchase_tax,
          cess: i.cess_tax_rate,
          tax_rate_id: i.tax_rate_id,
          cess_amount: i.cessp,
          cess_tax_rate_id: i.cess_tax_rate_id,
          lxb: { length_c: Number(i.length_c), breadth: Number(i.breadth) }
        });
      }
    } return this.finalItem
  }
  refreshInvoice() {
    window.location.assign('/sales-invoice');
    console.log("func calling refresh");
  }
  editInvoiceNo() {

    console.log("edit");
    this.dateChange()
    this.modal.dismiss();


  }
  sendSMS() {
    let header = this.api.getHeader();
    this.api.sendRemainder(this.invoiceID, header).subscribe((response: any) => {
      console.log(response, "pos data response");
    })
  }

  saveInvoice() {
    console.log("qqqqqq", this.items);

    this.putinarray()
    this.invoice_model.Igst = this.igst
    this.invoice_model.cgst = this.cgst
    this.invoice_model.sgst = this.sgst
    this.invoice_model.taxable_amount = this.total_taxable_amount
    this.invoice_model.total_amount = this.subTotal
    this.invoice_model.party = this.party_details.id
    this.invoice_model.items = this.finalItem
    this.invoice_model.receivable = this.finalAmount;
    this.invoice_model.partial_paid = this.partialPAid
    this.invoice_model.discount = this.invoice_model.discountTotal
    this.invoice_model.extra_charges_lst = this.exp1
    this.invoice_model.round_off = this.round_off
    this.invoice_model.einvoice=this.einvoice

    console.log(this.invoice_model, "invoice");
    if (this.finalItem.sales_tax) {
      this.invoice_model.items.tax_amount = this.finalItem.sales_tax
    }
    if (this.finalItem.purchase_tax) {
      this.invoice_model.items.tax_amount = this.finalItem.purchase_tax
    }
    if (this.finalItem.cess) {
      this.invoice_model.items.cess = this.finalItem.cess
    }
    if (this.items.tax_percent == -1) {
      console.log("expmted received in save",);
      this.invoice_model.items.tax_percent = -1
    }
    if (this.finalItem.cessp) {
      this.invoice_model.items.cess = this.finalItem.cessp
    }

    if (this.invoice_model.invoice_no && this.invoice_model.items.length && this.invoice_model.party) {
      console.log("valid form");

      this.submit = true
    } else {
      this.submit = false
      console.log("qwe INvalid form");
      // alert(this.translate.instant('MESSAGE.PLEASE ENTER REQUIRED FEILD'))

      if (this.submit == false) {
        if (!this.invoice_model.items.length) {
          console.log(this.invoice_model, "invoice");
          alert(this.translate.instant('MESSAGE.PLEASE ADD ITEMS'))
        }
        else if (!this.invoice_model.invoice_no) {
          console.log(this.invoice_model, "invoice");
          alert(this.translate.instant('MESSAGE.PLEASE ENTER INVOICE NUMBER'))
        }
      }

    }
    if (this.submit == true) {

      let companyId = this.api.getCompanyId()
      this.invoice_model.company_name = companyId;

      let header = this.api.getHeader();

      this.invoice_model.extra_charges_lst = this.exp1
      // this.invoice_model.extra_fields = this.extraF
      // console.log(this.extraF,"extraaaaaaaaaa");
      this.invoice_model.cess = this.total_cess_rate
      console.log("this.invoice_model", this.invoice_model);
      console.log(this.invSett.extra_fields, 'invSett.extrafields');
      if (this.invoice_model.invoice_type == 1) {
        if (this.invoice_model.extra_fields.length != 0) {
          const extraF = this.invSett.extra_fields.map(({ extra_fields, extra_fieldsValue }) => ({ [extra_fields]: extra_fieldsValue }));
          console.log(extraF, 'extra fields');

          this.invoice_model.extra_fields = extraF
          console.log(this.invoice_model, 'invoice model create');
        }
        else {
          this.invoice_model.extra_fields = []
        }
      }
      this.api.createInvoice(this.invoice_model, header).subscribe(async (response: any) => {
        console.log("status of invioce", response);

        if (response.status_code == 0) {
          //alert(response["message"])
          this.finalItem = []
          const toast = await this.toastController.create({
            message: response["message"],
            duration: 3000,
            color: "warning"
          });
          toast.present();
        }
        if (response.status_code == 3) {
          if (this.invoice_type == 1) {
            const toast = await this.toastController.create({
              message: this.translate.instant("MESSAGE.SALES INVOICE CREATED SUCCESSFULLY"),
              duration: 3000,
              color: "warning"
            });
            toast.present();
          }
          if (this.invoice_type == 2) {
            const toast = await this.toastController.create({
              message: this.translate.instant("MESSAGE.PURCHASE INVOICE CREATED SUCCESSFULLY"),
              duration: 3000,
              color: "warning"
            });
            toast.present();
          }
          if (this.invoice_type == 4) {
            const toast = await this.toastController.create({
              message: this.translate.instant("MESSAGE.PURCHASE RETURN CREATED SUCCESSFULLY"),
              duration: 3000,
              color: "warning"
            });
            toast.present();
          }
          if (this.invoice_type == 3) {
            const toast = await this.toastController.create({
              message: this.translate.instant("MESSAGE.SALES RETURN CREATED SUCCESSFULLY"),
              duration: 3000,
              color: "warning"
            });
            toast.present();
          }
          if (this.invoice_type == 5) {
            const toast = await this.toastController.create({
              message: this.translate.instant("MESSAGE.QUOTATION CREATED SUCCESSFULLY"),
              duration: 3000,
              color: "warning"
            });
            toast.present();
          }
          if (this.invoice_type == 6) {
            const toast = await this.toastController.create({
              message: this.translate.instant("MESSAGE.CHALLAN CREATED SUCCESSFULLY"),
              duration: 3000,
              color: "warning"
            });
            toast.present();
          }
          if (this.invoice_type == 7) {
            const toast = await this.toastController.create({
              message: this.translate.instant("MESSAGE.PROFORMA INVOICE CREATED SUCCESSFULLY"),
              duration: 3000,
              color: "warning"
            });
            toast.present();
          }
          console.log(response.data);
          console.log(JSON.parse(sessionStorage.getItem("currentCompany")), "compp")


          this.invoiceD = response.data

          this.downloadUrl = 'https://api.esarwa.com/api/create_pdf/' + response["data"] + '/';


          this.invoiceID = response.data
          console.log("invoiceID", this.invoiceID);
          if (response.data != null) {
            if(this.invoice_type == 1){
            if (this.eInvoice) {
              this.createEInvoice(response.data)
            }
            if (this.eWayBill == true) {
              if (this.vehicleDetails == true) {
                console.log("eway true");
                this.vehicleSubmitted.invoice = response.data

                console.log(this.vehicleSubmitted, "vehicle");

                this.api.submitTransportDetails(this.vehicleSubmitted).subscribe((response: any) => {
                  console.log("submit transport", response);
                  if (response.status == 200) {
                    this.createEwayBill(this.invoiceID);
                  }
                })

              }
            }
          }
          }
        }
      });
    }

  }
  createEInvoice(data: any) {
    let company_id = this.api.getCompanyId()
    this.api.geteinvoice({ "invoice_id": this.invoiceID, "company_id": company_id }).subscribe((response: any) => {
      console.log(response, "e invoice result");
      if (response.status == 200) {
        this.downloadEinvoiceButton = true
        this.downloadEinvoicePDF(data);


      } else if (response.status == 500) {
        this.einvoiceErrorInfo = response.msg;
        this.einvoiceErrorInfoShow = true;
        // setTimeout(function () { /* snip */  }, 500)
      }
    })
  }

  openEwayBill(ewaybill: any) {
    this.downloadEwaybill = 'https://esarwa.com/ewaybill/index.php?inv=8928';
  }
  convertToPDF() {
    const doc = new jsPDF('p', 'mm', 'a4'); // Specify custom width and height
    const url = 'https://esarwa.com/ewaybill/index.php';
    let h = JSON.stringify(this.ePost);
    console.log(h, "posting data eway");


    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: h,
    })
      .then((response) => response.text())
      .then((html) => {
        const opt = {
          margin: [10, 10, 10, 10], // Specify the margins
          filename: 'E-way bill.pdf',
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
        };

        html2pdf().from(html).set(opt).save();
      })
      .catch((error) => {
        console.error('Error:', error);
      });

  }

  ewaySubmit(d: any) {
    this.vehicleDetails = true
    console.log("submit eway", d);
    this.vehicleSubmitted = d
    this.modal.dismiss()
  }
  createEwayBill(data: any) {
    this.api.createEwb({ invoice_id: data }).subscribe(async (response: any) => {
      console.log("create eway bill response", response);
      if (response.status == 200) {
        const toast = await this.toastController.create({
          message: response.msg,
          duration: 3000,
          color: "success"
        });
        toast.present();
        console.log(response.data, "eway bill created");
        this.ewaybillDownload = true
        this.get_ewb(data);
      }
      else if(response.status ==500){
        alert(response.msg)
        // const toast = await this.toastController.create({
        //   message: response.msg,
        //   duration: 2000,
        //   color: "warning"
        // });
        // toast.present();
      } else {
        const toast = await this.toastController.create({
          message: "Failed",
          duration: 2000,
          color: "warning"
        });
        toast.present();
        console.log(response.msg);
        this.einvoiceErrorInfo = response.msg;
        this.einvoiceErrorInfoShow = true;
      }
    })
  }
  closeEinvoiceErrorDialog() {
    this.einvoiceErrorInfoShow = false;
  }
  get_ewb(data) {
    this.api.get_ewb({ invoice_id: data }).subscribe((response: any) => {
      console.log("ewaybill", response);
      if (response.status == 200) {
        this.e = response.data;
        this.ePost = response
        // this.ebarcode = this.e.ewbNo + "/" + this.e.userGstin + "/" + this.e.ewayBillDate;
      }
    })
  }
  eway: any = {
    vehicle_type: null,
    trans_mode: null,
    vehicle_no: null,
    distance: null,
    disp_gst: null,
    disp_name: null,
    ship_gst: null,
    ship_name: null,
    transporter_name: null,
    transporter_id: null
  }
  vehicle_type: any = [{ id: "0", name: "Regular" }, { id: "1", name: "Over-Dimensional Cargo" }]
  transport_type: any = [{ id: 1, name: "Road" }, { id: 2, name: "Rail" }, { id: 3, name: "Air" }, { id: 4, name: "Ship" }]

  collectPayment() {
    this.api.collectPaymentPos(this.invoiceD).subscribe((response: any) => {
      console.log(response, "pos data response");
      this.merchanTrans_id = response.body.merchantTransactionId

      this.statusbutton = true
      this.progressWheel = true
    })
  }
  getPayStatus() {
    this.api.getPaymentStatus(this.invoiceD, this.merchanTrans_id).subscribe((response: any) => {
      console.log(response, "Staus REsponse");
      this.payentStatusPOS = response
      if (response.result.resultStatus === 'FAIL') {
        alert(this.translate.instant('MESSAGE.PAYMENT FAILED'))
        this.resendbutton = true
      } else if (response.result.resultStatus === 'PENDING') {
        alert(this.translate.instant('MESSAGE.PLEASE CHECK EDC MACHINE'))
      }
      else {
        alert(this.translate.instant('MESSAGE.PAYMENT SUCCESSFUL'))
        this.paymentDone = true
        this.progressWheel = false
      }
    })
  }
  addAnotherCharges() {
    this.addCharge = true
    let data = {
      extra_charges: "",
      extra_amt: 0,
    }
    this.exp1.push(data);

  }
  total1() {
    let ff = 0;
    this.exp1.forEach(function (value) {
      ff = value.extra_amt + ff;
    });
    this.charge = ff;
    this.invoice_model.extraCharged = Number(this.charge)

    this.calculation()
  }
  deleteRow(i: number) {
    this.exp1.splice(i, 1);
    this.total1()
  }
  deleteRow1(i: number) {
    console.log("delete");

    this.extraF.splice(i, 1)
  }
  Change() {
    if (this.invoice_model.checked) {
      this.partialPAid = 1
    } else {
      this.partialPAid = 0
    }
    console.log(this.partialPAid);
  }

  einvoice(d: any) {
    console.log(d, "invoice");
    if (this.eInvoice == true) {
    }
  }
  downloadEinvoicePDF(id: any) {
    this.downloadEinvoicePDF1 = 'https://api.esarwa.com/einvoicing/create_pdf/' + id + '/';

    // https://api.esarwa.com/einvoicing/create_pdf/1672/
    // this.api.getEinvoicePDF(id).subscribe((response:any)=>{console.log(response,"downloading ein");
    // })

  }
  async ewayBill1() {

    console.log("show", this.eWayBill);
    const modal = await this.modal.create({
      component: EWayPage,

      breakpoints: [0, 0.3, 0.5, 1],
      initialBreakpoint: 0.8
    });
    modal.onDidDismiss()
      .then((data) => {
        console.log("closedata", data);
        this.ewaySubmit(data.data);
      });
    return await modal.present();
  }

  supply() {
    this.api.receivedState().subscribe((response: any[]) => {
      this.place_of_supply = response["data"]
      console.log("state", this.place_of_supply);
      this.place = this.place_of_supply
      if (this.place) {
        this.placeOf = this.party_details.gst_compare
        this.place.place_of_supply = Number(this.placeOf)
        if (this.place.place_of_supply < 10) {
          this.placeOf = "0" + this.invoice_model.place_of_supply.toString()
          console.log(this.placeOf, "ppppppp");
        }
        else {
          this.placeOf = this.invoice_model.place_of_supply.toString()
          console.log(this.placeOf, "else");
        }
      }
      this.calculation();
      this.calculateTax();
      this.calculateGst();
    });
  }
  async setting() {
    console.log("click");
    const modal = await this.modal.create({
      component: InvoiceSettingPage,

      // breakpoints: [0, 0.3, 0.5, 1],
      // initialBreakpoint: 0.8
    });
    modal.onDidDismiss()
      .then(async (data) => {
        console.log("closedata");
        this.invoice_head();
        const user = data.data; // Here's your selected user!
        // const toast = await this.toastController.create({
        //   message: "Invoice setting updated successfully",
        //   duration: 2000,
        //   color: "warning"
        // });
        // toast.present();
      });
    return await modal.present();
  }
  segmentChanged(event: any) {
    this.selectSegment = event.target.value;

    console.log(event.detail.value);
    console.log(this.selectSegment, "selected segment");
  }

  onSegmentChange(event) {
    console.log(event.detail.value);
  }
  dismis() {
    this.modal.dismiss();
  }

  getGSTrate() {
    let header = this.api.getHeader();
    this.api.receivedGST(header).subscribe((response: any[]) => {
      console.log(response);
      this.gstData = response
    });
  }
  selectgstrate(data: any, index) {
    console.log(data, index, 'uuuiok');
    console.log(data.multiple, 'multiple rates');
    // // let  a=1000
    // (data.rate > item.to_rate || !item.to_rate)
    if (data.multiple_rates && data.multiple.length != 0) {

      let t = []
      if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
        t = data.multiple.filter((item) => item.from_rate <= data.rate && item.to_rate >= data.rate)

      } else if (this.invoice_type == 2 || this.invoice_type == 4) {
        t = data.multiple.filter((item) => item.from_rate <= data.purchase_rate && item.to_rate >= data.purchase_rate)

      }
      console.log(t, 'jjj');
      if (t.length != 0) {
        this.p = this.gstData.filter((item) => item.id === t[0].tax)
        console.log(this.p[0], "tax rate gggg");
        if (data.id == this.items[index].id && this.p.length != 0) {
          this.items[index].Gst_tax_rate = (this.p[0].gst_tax_rate);
          this.items[index].gst_id = this.p[0].id
          this.items[index].tax_rate_id = (this.p[0].id)
        }

        console.log(data.id, this.items[index].id, "tax rate mmm");
      } else {
        console.log(data.Gst_tax_rate, 'lllopkjhhbjfdvjnb');

        this.items[index].gst_id = (data.tax_rate_id)
      }
      console.log(this.items, 'llolp');

      this.calculation();
      //  this.calculateTax();
    }
  }
  ratechange(i: any, d: any) {
    console.log(i, "ratechange");
    let last_selected = i
    let c = this.gstData.filter((item) => item.id === Number(i.gst_id))
    console.log(c, "c");

    if (c.length != 0) {
      this.items[d].Gst_tax_rate = (c[0].gst_tax_rate);
      this.items[d].tax_rate_id = (c[0].id)
    } else {
      this.items[d].Gst_tax_rate = (last_selected.Gst_tax_rate);
      this.items[d].tax_rate_id = (last_selected.tax_rate_id)
    }
    console.log(this.name.Gst_tax_rate, 'gsttaxratetttd');

    this.calculation();
    // this.calculateTax();

  }
  WHFunction(t: any) {
    this.items[t].quantity = this.items[t].breadth * this.items[t].length_c
    this.calculation();
  }
}
