import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ApiService } from "../api.service";
import { ToastController } from "@ionic/angular";
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as CryptoJS from 'crypto-js';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  @Output() passwordStrength = new EventEmitter<boolean>();
  showPassword: boolean = true;
  passwordIsValid = false;
  data: any = [];
  user: any = {};
  response: any = {};
  message: boolean;
  message_text: any = false;
  loginForm: FormGroup;
  otpForm: FormGroup;
  login: Boolean = true;
  otp: Boolean = false;
  createPassword: Boolean = false;
  otpNumber: Boolean = false;
  otpNumberRegister: Boolean = false;
  register: Boolean = false;
  otpButton: any = "Send OTP";
  newPasswordForm: FormGroup;
  registerForm: FormGroup;
  registration: Boolean;
  registrationForm: FormGroup;
  //4512631236589784
  //F6ADE828471E9
  private key = CryptoJS.enc.Utf8.parse('Xp2s5v8y/B?E(H+M');
  private iv = CryptoJS.enc.Utf8.parse('Xp2s5v8y/B?E(H+M');
  msg: string;
  reactive: boolean;

  constructor(private api: ApiService,
    public toastController: ToastController,
    private translate: TranslateService,
    private router: Router,
    public formBuilder: FormBuilder) {
    this.loginForm = formBuilder.group({
      // 'email':[null,Validators.required],
      'email': ['', Validators.compose([Validators.required, Validators.pattern(/^(?:\d{10}|\w+@\w+\.\w{2,3})$/)])],
      'password': [null, Validators.required]
    })
    this.otpForm = formBuilder.group({
      'mobile_number': ["", Validators.compose([Validators.required, Validators.pattern(/^[6-9]{1}[0-9]{9}$/)])],
      'otp': [""]
    })
    this.newPasswordForm = formBuilder.group({
      'new_password': [null, Validators.required],
      'conf_password': [null, Validators.required],
      'token_id': [null]
    })
    this.registerForm = formBuilder.group({
      'mobile_number': ["", Validators.compose([Validators.required, Validators.pattern(/^[6-9]{1}[0-9]{9}$/)])],
      'version_id': ['1.0.9'],
      'otp': [null]

    })
    this.registrationForm = formBuilder.group({
      "f_name": [null, Validators.required],
      "l_name": [null, Validators.required],
      "email": ['', Validators.compose([Validators.required, Validators.pattern(/^(?:\d{10}|\w+@\w+\.\w{2,3})$/)])],
      "password": [null, Validators.required],
      "c_password": [null],
      "token_id": [null, Validators.required],
      "mobile": [null, Validators.compose([Validators.required, Validators.pattern(/^[6-9]{1}[0-9]{9}$/)])],
      "isPasswordUpdate": ["yes"]

    })

  }

  ngOnInit() {
    this.registrationForm.patchValue({
      'mobile': localStorage.getItem("mobile"),
      "token_id": localStorage.getItem("token_id")
    })

    this.checkLogin();
    // let loginData = JSON.parse(sessionStorage.getItem("loginData"));
    //     let token = loginData["token_id"];
    //     if (token != null) {
    //       this.router.navigate(['/show-company-list'])
    //     }else{
    //       console.log("Please Login");
    //     }
    let data = { username: "9167210211", password: "12345" }

    this.encryptUsingAES256(JSON.stringify(data))
    //  console.log();

    // console.log(JSON.parse("{\"username\":\"9594319954\",\"password\":\"12345678\"}"));

    console.log('Xp2s5v8y/B?E(H+M'.length);



  }

  encryptUsingAES256(plaintext: any) {
    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(JSON.stringify(plaintext)), this.key, {
      keySize: 128 / 8,
      iv: this.iv,
      mode: CryptoJS.mode.CBC
    });
    console.log('Encrypted :' + encrypted);
    //this.decryptUsingAES256(encrypted);
    return encrypted;
  }

  // decryptUsingAES256(decString) {
  //     var decrypted = CryptoJS.AES.decrypt(decString, this.key, {
  //         keySize: 128 / 8,
  //         iv: this.iv,
  //         mode: CryptoJS.mode.CBC,
  //         padding: CryptoJS.pad.Pkcs7
  //     });
  //     console.log('Decrypted : ' + decrypted);
  //     console.log('utf8 = ' + decrypted.toString(CryptoJS.enc.Utf8));

  // }

  checkLogin() {
    if (sessionStorage != null) {
      //  console.log("session is not null");
      // this.router.navigate(['/show-company-list'])
      if (sessionStorage["loginData"] == null) {
        console.log("Please Login");

      } else {
        let loginData = JSON.parse(sessionStorage.getItem("loginData"));
        let token = loginData["token_id"];
        if (token != null) {
          this.router.navigate(['/show-company-list'])
        }
      }
    }
  }

  public OnlyNumbers($event) {
    let regex: RegExp = new RegExp(/^[0-9]{1,}$/g);
    let specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', 'ArrowRight', 'ArrowLeft'];
    if (specialKeys.indexOf($event.key) !== -1) {
      return;
    } else {
      if (regex.test($event.key)) {
        return true;
      } else {
        return false;
      }
    }
  }

  submitForm1() {
    this.api.showLoading();
    console.log(this.loginForm.value);


    if (this.loginForm.valid) {

      this.api.login(this.loginForm.value).subscribe((response: any) => {
        console.log('1', response);
        if (response.status == 'failed') {

          this.message = true;
          // this.message_text=response.message;
          this.presentToast(response.message)
          if (!response.message) {
            this.msg = response.data
            this.reactive = true
            this.presentToast(this.msg)
          }
          if (response.data.status == 401) {
            this.msg = this.translate.instant('MESSAGE.USER NOT EXISTS')
            this.presentToast(response.data.data)
            this.reactive = false
          }

        } else if (response.status == 'success') {
          sessionStorage.setItem('loginData', JSON.stringify(response));

          this.router.navigate(['/show-company-list'])
        }
      });
    }

  }
  showOtp() {
    this.otp = true;
    this.login = false;

  }
  submitForm2() {

    if (this.otpForm.valid) {
      console.log("data", this.otpForm.value);
      localStorage.setItem("mobile", this.otpForm.value.mobile_number)
      this.api.forgotPassword(this.otpForm.value).subscribe((response: any) => {
        console.log("after forgot password ", response);

        if (response.status == "1") {
          this.otpNumber = true
          this.presentToast1(response.message)
        }
        if (response.status == "0") {
          this.presentToast1(response.message)
          this.otp = false
          this.register = true
        }
        //   {
        //     "status": "1",
        //     "message": "You are not a register User, Register first!!"
        // }

      })


    }
  }
  submitForm3() {
    this.createPassword = true
    this.otp = false


  }
  submitFormVerify() {
    //this.createPassword=true
    // this.otp=false
    // let token_id=localStorage.getItem("token_id");

    if (this.registerForm.valid) {
      console.log("data", this.registerForm.value);
      this.api.verifyPassword(this.registerForm.value).subscribe((response: any) => {
        console.log("after verify password ", response);
        if (response.status == "1") {
          this.register = false,
            this.registration = true
          this.presentToast1(response.message)
          localStorage.setItem("token_id", response.token_id)
        } else {
          this.presentToast(response.message)
        }

        //   {
        //     "status": "1",
        //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
        //     "message": "Otp verified successfully!!"
        // }

      })

    }

  }

  submitFormVerify1() {
    // this.createPassword=true
    // this.otp=false
    // let token_id=localStorage.getItem("token_id");

    if (this.otpForm.valid) {
      console.log("data", this.otpForm.value);
      this.api.verifyPassword(this.otpForm.value).subscribe((response: any) => {
        console.log("after verify password ", response);
        if (response.status == "1") {
          this.otp = false,
            this.createPassword = true
          this.presentToast1(response.message)
          localStorage.setItem("token_id", response.token_id)
        } else {
          this.presentToast(response.message)
        }

        //   {
        //     "status": "1",
        //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
        //     "message": "Otp verified successfully!!"
        // }

      })


    }

  }

  savePassword() {
    let token_id = localStorage.getItem("token_id");


    if (this.newPasswordForm.valid) {
      this.newPasswordForm.patchValue({
        'token_id': token_id
      })
      console.log("data", this.newPasswordForm.value);
      let newData = { username: localStorage.getItem("mobile"), password: this.newPasswordForm.value.new_password }
      this.api.savePassword(this.newPasswordForm.value).subscribe((response: any) => {
        console.log("after password save", response);
        if (response.status == "1") {
          // this.newPasswordForm.value.new_password

          console.log("post for forgot password", newData);
          let enscrypted = this.encryptUsingAES256(JSON.stringify(newData))
          console.log("encrypted : ", enscrypted.ciphertext.toString(CryptoJS.enc.Base64))
          let data = { data: enscrypted.ciphertext.toString(CryptoJS.enc.Base64) }
          this.api.forgot_password(data).subscribe((response: any) => {
            console.log("updated", response);

          })


          this.presentToast1(response.message)
          this.login = true
          this.createPassword = false
          //localStorage.setItem("token_id",response.token_id)
        } else {
          this.presentToast(response.message)
        }
        //   {
        //     "status": "1",
        //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
        //     "message": "Otp verified successfully!!"
        // }

        //   {
        //     "status": "1",
        //     "message": "Your password has been updated successfully!!"
        // }

      })
    }

  }

  signup() {

    this.login = false
    this.register = true;

  }
  sendRegisterOtp() {


    if (this.registerForm.valid) {
      console.log("data", this.registerForm.value);
      localStorage.setItem("mobile", this.registerForm.value.mobile_number)
      this.api.sendOtp(this.registerForm.value).subscribe((response: any) => {
        // console.log("after forgot password ",response);
        this.presentToast(response.message)
        if (response.status == "1") {
          this.presentToast1(response.message)
          this.otpNumberRegister = true
          // this.login=true
          //this.createPassword=false
          //localStorage.setItem("token_id",response.token_id)
        } else {
          this.presentToast1(this.translate.instant('MESSAGE.YOU ARE ALREADY REGISTERD'))
          this.login = true
          this.register = false;

        }
        //   {
        //     "status": "1",
        //     "message": "Otp has been sent to your registered mobile"
        // }

      },
        error => {
          this.presentToast1(this.translate.instant('MESSAGE.YOU ARE ALREADY REGISTERD'))
          this.login = true
          this.register = false;
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        })


    }

  }

  submitRegisterVerify() {
    // this.createPassword=true
    //this.otp=
    //this.register
    // let token_id=localStorage.getItem("token_id");

    if (this.registerForm.valid) {
      console.log("data", this.otpForm.value);
      this.api.verifyPassword(this.registerForm.value).subscribe((response: any) => {
        console.log("after verify password ", response);
        if (response.status == "1") {
          this.presentToast1(response.message)
          localStorage.setItem("token_id", response.token_id)
          this.register = false
          this.registration = true;
        } else {
          this.presentToast(response.message)
        }

        //   {
        //     "status": "1",
        //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
        //     "message": "Otp verified successfully!!"
        // }

      })


    }

  }

  registerSubmit() {
    this.registrationForm.patchValue({
      'mobile': localStorage.getItem("mobile"),
      "token_id": localStorage.getItem("token_id")
    })

    console.log("this.registrationForm.value", this.registrationForm.value);

    if (this.registrationForm.valid) {
      console.log("data", this.registrationForm.value);
      this.api.registersubmit(this.registrationForm.value).subscribe((response: any) => {
        console.log("after registration submit ", response);

        if (response.status == "1") {
          this.presentToast1(response.message)
          // localStorage.setItem("token_id",response.token_id)
          //  this.register=false
          this.registration = false;
          this.login = true;
          let data = {
            "first_name": this.registrationForm.value.f_name,
            "last_name": this.registrationForm.value.l_name,
            "username": this.registrationForm.value.mobile,
            // "token_id":this.registrationForm.value.token_id,
            "email": this.registrationForm.value.email,
            "password": this.registrationForm.value.password,
            // "mobile": this.registrationForm.value.mobile,
            // "isPasswordUpdate": this.registrationForm.value.isPasswordUpdate
          }
          this.api.registersubmit1(data).subscribe((response: any) => {
            console.log("registration submit1 ", response);
          })
        } else {
          this.presentToast(response.message)
        }

        //   {
        //     "status": "1",
        //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
        //     "message": "Otp verified successfully!!"
        // }
      })

    }
  }




  async presentToast(message: any) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: 'danger',
      buttons: [
        {
          text: 'OK',
          cssClass: "toast-scheme",
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    toast.present();
  }
  async presentToast1(message: any) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: 'success',
      buttons: [
        {
          text: 'OK',
          cssClass: "toast-scheme",
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    toast.present();
  }


  submitdata() {


    // let data = JSON.stringify(this.user)
    this.api.login(this.user).subscribe((response: any) => {
      console.log('1', response);
      if (response.status == 'failed') {
        this.message = true;
        this.message_text = response.message;
      } else if (response.status == 'success') {
        sessionStorage.setItem('loginData', JSON.stringify(response));
        this.router.navigate(['/show-company-list']).then(() => {
          window.location.reload();
        });
      }
    });
  }
  //   console.log("test", this.user);
  //  // this.api.post(this.user.username, this.user.password)
  //     .subscribe((response: any[]) => {
  //       alert(response);
  //       console.log("response",response);
  //       sessionStorage.setItem('loginData',JSON.stringify(response));

  //       this.router.navigate(['/tabs/tab1'])
  //     }, (error) => {
  //       console.log('error from service', error);
  //       if (error.status == 401) {
  //         console.log("invalid credentials..!");


  cpassword() {
    if (this.registrationForm.value.password != this.registrationForm.value.c_password) {
      this.msg = this.translate.instant('MESSAGE.PASSWORD NOT MATCHING')
    } else {
      this.msg = this.translate.instant('MESSAGE.PASSWORD MATCHED')
    }
  }

  passwordValid(event) {
    this.passwordIsValid = event;
  }
  async reactiveAccount() {
    console.log("clicked");
    const toast = await this.toastController.create({
      header: this.translate.instant('MESSAGE.ARE YOU SURE YOU WANT TO REACTIVE THIS ACCOUNT ?'),
      position: "bottom",
      buttons: [
        {
          text: this.translate.instant('HEADER.YES'),
          role: "done",
          handler: async () => {
            console.log("loginForm", this.loginForm.value.email);
            this.api.reactiveAccount(this.loginForm.value.email).subscribe(async (response: any) => {
              console.log("rsponse", response);

              if (response.status == 200) {
                const toast = await this.toastController.create({
                  message: this.translate.instant('MESSAGE.ACCOUNT SUCCESSFULLY ACTIVATED'),
                  duration: 2000,
                  color: "success"
                });
                toast.present();
              }
            })
            this.reactive = false
          },
        },
        {
          text: this.translate.instant('HEADER.CANCEL'),
          role: "cancel",
          handler: async () => {
          }
        },
      ],
    });
    toast.present();

  }
  togglePassword(input: any) {
    this.showPassword = !this.showPassword
    input.type = input.type === 'password' ? 'text' : 'password';

  }
}
