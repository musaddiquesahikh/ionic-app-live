import { Component, OnInit ,ViewChild} from '@angular/core';
import { IonInfiniteScroll } from '@ionic/angular';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-infinity',
  templateUrl: './infinity.page.html',
  styleUrls: ['./infinity.page.scss'],
})
export class InfinityPage implements OnInit {
  @ViewChild(IonInfiniteScroll) infiniteScroll: IonInfiniteScroll;

  constructor(public api:ApiService) { }

  currentPage:number=1
  users:any=[]

  total:number=0

  ngOnInit() {
this.getData();
  }

  getData(){
    this.api.fakeData(this.currentPage).subscribe((response:any)=>{
      console.log(response);
      let data=response.data
      for(let n of data){
          this.users.push(n)
      }
     // this.users.push(data)
      this.total=response.total
      
    })

  }

  doInfinite(infiniteScroll) {
    console.log('Begin async operation');

   setTimeout(() => {
      // for (let i = 0; i < 30; i++) {
      //   this.items.push( this.items.length );
      // }
      
      this.currentPage++
      this.getData()

      console.log('Async operation has ended');
      //infiniteScroll();
      infiniteScroll.target.complete();
      //console.log(infiniteScroll);
      
    }, 500);
  }
  // doInfinite(): Promise<any> {
  //   console.log('Begin async operation');

  //   return new Promise((resolve) => {
  //     setTimeout(() => 
  //     {
  //       this.getData();
  //       for (var i = 0; i < 30; i++) {
  //         this.users.push( this.users.length );
  //       }

  //       console.log('Async operation has ended');
  //       resolve
  //      console.log("completed", this.users);
       
  //     }, 500);
  //   })
  // }
}
