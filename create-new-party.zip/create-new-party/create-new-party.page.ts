import { Location } from '@angular/common';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController, NavController, ToastController } from '@ionic/angular';
import { modalController } from '@ionic/core';
import { ApiService } from "../api.service";
import { TranslateService } from '@ngx-translate/core';
import { PermissionGuard } from '../guards/permission.guard';

@Component({
  selector: 'app-create-new-party',
  templateUrl: './create-new-party.page.html',
  styleUrls: ['./create-new-party.page.scss'],
})
export class CreateNewPartyPage implements OnInit {
  data: any = {};
  user: any = {};
  submit:boolean=false;
  place_of_supply:any=[]
  public isChecked = true;
  x:any={}
  pan: any
  createpartypush: any = {}
  result: any;
  createParty: any = {};
  partyDetails: any = {
    company_name: '',
    Party_name: "",
    mobile_number: '',
    email: "",
    opening_balance: '',
    current_balance: '',
    opening_balance_type: '',
    party_type: '',
    gstin: '',
    place_of_supply: '',
    billing_address: "",
    shipping_address: "",
    credit_period: '',
    credit_limit: 0,
    city: '',
    contact_person: '',
     pan: "",
    payment_type: ''
  };
  @Output() parentFunction: EventEmitter<any> = new EventEmitter();
  gstmessage: any;
  defaultSelectQuestion: number;
  constructor(public toastController: ToastController, public api: ApiService, public router: Router,
    public navCtrl: NavController,public location:Location, public modalCtrl:ModalController,private translate: TranslateService,
    public alertCtrl:AlertController,public permission:PermissionGuard) { }

  ngOnInit() {
     this.user.party_type = '1'
     this.user.payment_type = '1'
     this.user.opening_balance = 0
     this.user.current_balance = 0
     this.user.credit_period = 0
     this.user.payment_type = "Debit"
     this.user.place_of_supply = 1
     this.user.credit_limit = 0
     this.user.gstin = null
    this.api.receivedState().subscribe((response: any[]) => {
      console.log(response);
      this.place_of_supply=response["data"]
      console.log("state",this.place_of_supply);
     this.permission1() 
      
    });

  }
  async saveData(user:any) {
    if(this.user.gstin == ""){
      this.user.gstin = null
    }
    console.log("user",user);
    
    if (user.Party_name && user.mobile_number && user.party_type && user.place_of_supply) {
      this.submit = true
      console.log("user1",user);
      
    } else {
      this.submit = false
      console.log("user2",user);
      
    }

    if (this.submit==true) {
    this.partyDetails = this.user;

   // this.createParty = JSON.parse(sessionStorage.getItem("selectedCompany"));
    let companyId = this.api.getCompanyId();
    console.log("party details", companyId);
    this.partyDetails.company_name = companyId;
   
    console.log("data", this.partyDetails);
    let header = this.api.getHeader();
    let data1 = JSON.stringify(this.partyDetails)
    this.api.createNewParty(this.partyDetails, header).subscribe(async (response: any) => {
      console.log("sdsfdsffds",response);
      let a=response.status
      if(a == 200)
      {
         const toast = await this.toastController.create({
          message:this.translate.instant('MESSAGE.PARTY CREATED SUCCESSFULLY'),
          duration: 2000,
          color: "success"
        });
        toast.present();
        this.x =response.data
        this.modalCtrl.dismiss(this.x)
        console.log("pppp",this.x);
         
      }else{
        const toast = await this.toastController.create({
          message: response.message,
          duration: 2000,
          color: "warning"
        });
        toast.present();
      }
     
      this.createpartypush = response["data"].id

      console.log("createPartypush", this.createpartypush)
      this.parentFunction.emit(this.createpartypush);
      // this.router.navigate(['/tabs/tab2']);

    });
  }else{
    const toast = await this.toastController.create({
      message:this.translate.instant('MESSAGE.PLEASE ENTER REQUIRED FEILD'),
      duration: 2000,
      color: "warning"
    });
    toast.present();
   }

  }
  modelDismiss() {
    modalController.dismiss();
  }
  onAddressSame() {
    if (this.isChecked == true) {
      console.log(this.isChecked);

      this.user.billing_address = this.user.shipping_address;
    }
    if(this.isChecked == false){
      this.user.billing_address = "";
    }
  }
  gstFunction() {
    this.pan = this.user.gstin;
    if(this.pan != undefined){
        this.user.pan = this.pan.substr(2, 10);
    }
  
  }

  displayValue2: any
  getValue(val: any) {
    console.log(val)

    this.displayValue2 = val.substr(2, 10)

  }
  back(){
    this.modalCtrl.dismiss(this.x)
  }
  async permission1() {

    for (let hh of this.permission.roles.data.permissions) {
      console.log("asd");

      if (hh.page_name == 'parties') {
        console.log("asd123", hh.actions.create);
        if (hh.actions.create == true) {
        } else {
          let alert = await this.alertCtrl.create({
            header: this.translate.instant('MESSAGE.UNAUTHORIZED'),
            message: this.translate.instant('MESSAGE.YOU ARE NOT AUTHORIZED TO VISIT THAT PAGE'),
            buttons: ['OK']
          });
          alert.present();
          this.location.back()
        }
      }
    }
  }

}