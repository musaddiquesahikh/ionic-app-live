import { Location } from '@angular/common';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController, NavController, ToastController } from '@ionic/angular';
import { modalController } from '@ionic/core';
import { ApiService } from "../api.service";
import { TranslateService } from '@ngx-translate/core';
import { PermissionGuard } from '../guards/permission.guard';

@Component({
  selector: 'app-create-new-party',
  templateUrl: './create-new-party.page.html',
  styleUrls: ['./create-new-party.page.scss'],
})
export class CreateNewPartyPage implements OnInit {
  data: any = {};
  user: any = {};
  submit:boolean=false;
  public isChecked = true;
  x:any={}
  pan: any
  createpartypush: any = {}
  result: any;
  createParty: any = {};
  partyDetails: any = {
    company_name: '',
    Party_name: "",
    mobile_number: "",
    email: "",
    opening_balance: '',
    opening_balance_type: '',
    party_type: '',
    gstin: null,
    place_of_supply: "",
    billing_address: "",
    shipping_address: "",
    credit_period: '',
    credit_limit: 0,
    city: '',
    contact_person: '',
     pan: "",
    payment_type: ''
  };
  @Output() parentFunction: EventEmitter<any> = new EventEmitter();
  gstmessage: any;
  defaultSelectQuestion: number;
  currentParty: any;
  place: any;
  place_of_supply: number;
  mobile_number:number;
  constructor(public toastController: ToastController, public api: ApiService, public router: Router,
    public navCtrl: NavController,public location:Location, public modalCtrl:ModalController,private translate: TranslateService,
    public alertCtrl:AlertController,public permission:PermissionGuard) { }

  ngOnInit() {
    this.currentParty = JSON.parse(sessionStorage.getItem('currentCompany'));

     this.user.party_type = '1'
     this.user.payment_type = '1'
     this.user.opening_balance = 0
     this.user.credit_period = 0
     this.user.payment_type = "Debit"
     this.user.credit_limit = 0
     this.user.gstin = null
     this.permission1() 

     this.api.receivedState().subscribe((response: any[]) => {
      this.place_of_supply = response["data"]
      console.log("state", this.place_of_supply);
      // this.place = this.place_of_supply
    });

  }
  async saveData(user:any) {
    // if (this.currentParty.sms_service === true) {
    //   if (user.Party_name && user.mobile_number && user.email  && user.payment_type && user.place_of_supply) {
    //     this.submit = true
    //     console.log(this.submit);
        
    //   } 
    //   else{
    //     this.submit = false
    //     console.log("user2",this.submit);
    //   }
    //   }
    if(user.gstin!=null){
      console.log((user.gstin.length),'submit party');
      if(user.gstin.length!=15){
        this.submit=false
        const toast = await this.toastController.create({
          message:this.translate.instant('MESSAGE. ENTER VALID GST NO'),
          duration: 5000,
          color: "success"
        });
        toast.present();
      }
      if(user.gstin.length==0){
        user.gstin=null
        this.submit=true
      }
    }
    else{
      this.user.gstin = null
    }
    
    if (user.Party_name && user.mobile_number && user.payment_type && user.place_of_supply) {
      this.submit = true
      console.log("user1",user);
      
    } else {
      this.submit = false
      console.log("user2",this.submit);
      
    }

    if (this.submit==true) {
      console.log(this.submit,"submit");
      
    this.partyDetails = this.user;
    user.place_of_supply = user.place_of_supply

    this.partyDetails.place_of_supply = user.place_of_supply
    // user.state_code = user.place_of_supply.state_code
    console.log(this.partyDetails);


   // this.createParty = JSON.parse(sessionStorage.getItem("selectedCompany"));
    let companyId = this.api.getCompanyId();
    console.log("party details", companyId);
    this.partyDetails.company_name = companyId;
   
    console.log("data", this.partyDetails);
    let header = this.api.getHeader();
    let data1 = JSON.stringify(this.partyDetails)
  
    this.api.createNewParty(this.partyDetails, header).subscribe(async (response: any) => {
      console.log("sdsfdsffds",response);
      let a=response.status
      if(a == 200)
      {
         const toast = await this.toastController.create({
          message:this.translate.instant('MESSAGE.PARTY CREATED SUCCESSFULLY'),
          duration: 2000,
          color: "success"
        });
        toast.present();
        this.x =response.data
        this.modalCtrl.dismiss()
        console.log("pppp",this.x);
        //  this.location.back()
      }else{
        const toast = await this.toastController.create({
          message: response.message,
          duration: 2000,
          color: "warning"
        });
        toast.present();
      }
     
      // this.createpartypush = response.data.id

      // console.log("createPartypush", this.createpartypush)
      // this.parentFunction.emit(this.createpartypush);
      // // this.router.navigate(['/tabs/tab2']);

    });
  }
  else {
    this.submit=false
    console.log("false");
    if(user.Party_name==undefined){
      const toast = await this.toastController.create({
        message:this.translate.instant('MESSAGE.ENTER PARTY NAME'),
        duration: 5000,
        color: "success"
      });
      toast.present();
    }
   
    // if(user.email==undefined){
    //   const toast = await this.toastController.create({
    //     message:this.translate.instant('MESSAGE.ENTER EMAIL ID'),
    //     duration: 5000,
    //     color: "success"
    //   });
    //   toast.present();
    // }
    if(user.mobile_number==undefined){
      const toast = await this.toastController.create({
        message:this.translate.instant('MESSAGE.ENTER MOBILE NUMBER'),
        duration: 5000,
        color: "success"
      });
      toast.present();
    }
    if(user.place_of_supply==undefined){
      const toast = await this.toastController.create({
        message:this.translate.instant('MESSAGE.SELECT STATE'),
        duration: 5000,
        color: "success"
      });
      toast.present();
   }
  }
}
  modalDismiss() {
    modalController.dismiss();
  }
  onAddressSame() {
    if (this.isChecked == true) {
      console.log(this.isChecked);

      this.user.billing_address = this.user.shipping_address;
    }
    if(this.isChecked == false){
      this.user.billing_address = "";
    }
  }
  gstFunction() {
    this.pan = this.user.gstin;
    if(this.pan != undefined){
        this.user.pan = this.pan.substr(2, 10);
    }
  
  }

  displayValue2: any
  getValue(val: any) {
    console.log(val)

    this.displayValue2 = val.substr(2, 10)

  }
  back(){
    this.modalCtrl.dismiss(this.x)
  }
  async permission1() {

    for (let hh of this.permission.roles.data.permissions) {
      console.log("asd");

      if (hh.page_name == 'parties') {
        console.log("asd123", hh.actions.create);
        if (hh.actions.create) {
        } else {
          let alert = await this.alertCtrl.create({
            header: this.translate.instant('MESSAGE.UNAUTHORIZED'),
            message: this.translate.instant('MESSAGE.YOU ARE NOT AUTHORIZED TO VISIT THAT PAGE'),
            buttons: ['OK']
          });
          alert.present();
          this.location.back()
          // modalController.dismiss()
        }
      }
    }
  }

}