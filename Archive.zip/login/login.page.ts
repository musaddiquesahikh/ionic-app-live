import { Component, OnInit } from '@angular/core';
import { ApiService } from "../api.service";
import { ToastController } from "@ionic/angular";
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  data: any = [];
  user: any = {};
  response: any = {};
  message: boolean;
  message_text: any=false;
  loginForm:FormGroup;
  otpForm:FormGroup;
  login:Boolean=true;
  otp:Boolean=false;
  createPassword:Boolean=false;
  otpNumber:Boolean=false;
  otpNumberRegister:Boolean=false;
  register:Boolean=false;
  otpButton:any="Send OTP";
  newPasswordForm: FormGroup;
  registerForm: FormGroup;
  registration:Boolean;
  registrationForm: FormGroup;
  //4512631236589784
  F6ADE828471E9
  private key = CryptoJS.enc.Utf8.parse('Xp2s5v8y/B?E(H+M');
private iv = CryptoJS.enc.Utf8.parse('Xp2s5v8y/B?E(H+M');

  constructor(private api: ApiService,
     public toastController: ToastController,
     private router: Router,
     public formBuilder:FormBuilder) { 
        this.loginForm=formBuilder.group({
          'email':[null,Validators.required],
          'password':[null,Validators.required]
        })
        this.otpForm=formBuilder.group({
          'mobile_number':[null,Validators.required],
          'otp':[null]
        })
        this.newPasswordForm=formBuilder.group({
          'new_password':[null,Validators.required],
          'conf_password':[null,Validators.required],
          'token_id':[null]
        })
        this.registerForm=formBuilder.group({
          'mobile_number':[null,Validators.required],
          'version_id':['1.0.9'],
          'otp':[null]
          
        })
        this.registrationForm=formBuilder.group({
          "f_name":[null,Validators.required],
          "l_name":[null,Validators.required],
          "email":[null,Validators.required],
          "password":[null,Validators.required],
          "token_id":[null,Validators.required],
          "mobile":[null,Validators.required],
          "isPasswordUpdate":["yes"]
          
        })

  }

  ngOnInit() {

    this.checkLogin();
    // let loginData = JSON.parse(sessionStorage.getItem("loginData"));
    //     let token = loginData["token_id"];
    //     if (token != null) {
    //       this.router.navigate(['/show-company-list'])
    //     }else{
    //       console.log("Please Login");
    //     }
    let data={username:"9594319954",password:"12345678"}

    this.encryptUsingAES256(JSON.stringify(data))
    console.log(JSON.parse("{\"username\":\"9594319954\",\"password\":\"12345678\"}"));
    
    console.log('Xp2s5v8y/B?E(H+M'.length);
    
     

  }

  encryptUsingAES256(plaintext:any) {
    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(JSON.stringify(plaintext)), this.key, {
        keySize: 128 / 8,
        iv: this.iv,
        mode: CryptoJS.mode.CBC
    });
   // console.log('Encrypted :' + encrypted);
    //this.decryptUsingAES256(encrypted);
    return encrypted;
}

// decryptUsingAES256(decString) {
//     var decrypted = CryptoJS.AES.decrypt(decString, this.key, {
//         keySize: 128 / 8,
//         iv: this.iv,
//         mode: CryptoJS.mode.CBC,
//         padding: CryptoJS.pad.Pkcs7
//     });
//     console.log('Decrypted : ' + decrypted);
//     console.log('utf8 = ' + decrypted.toString(CryptoJS.enc.Utf8));

// }

  checkLogin(){
    if (sessionStorage != null) {
    //  console.log("session is not null");
      // this.router.navigate(['/show-company-list'])
      if (sessionStorage["loginData"] == null) {
        console.log("Please Login");

      } else {
        let loginData = JSON.parse(sessionStorage.getItem("loginData"));
        let token = loginData["token_id"];
        if (token != null) {
          this.router.navigate(['/show-company-list'])
        }
      }
    }
  }

  

  submitForm1(){
    this.api.showLoading();
    console.log(this.loginForm.value);
    

    if(this.loginForm.valid){

      this.api.login(this.loginForm.value).subscribe((response: any) => {
        console.log('1', response);
        if(response.status=='failed'){
          this.message=true;
         // this.message_text=response.message;
         this.presentToast(response.message)
         if(response.message==undefined){
          this.presentToast(response.token)
         }
         // this.presentToast(response.token)
        }else if(response.status=='success'){
          sessionStorage.setItem('loginData', JSON.stringify(response));

          this.router.navigate(['/show-company-list']).then(() => {
           // window.location.reload();
          });
        }
      });
    }

   //   console.log("is valid",this.loginForm.value);

  }
  showOtp(){
    this.otp=true;
    this.login=false;
    
  }   
  submitForm2(){
    this.otpNumber=true
    if(this.otpForm.valid){
      console.log("data",this.otpForm.value);
      localStorage.setItem("mobile",this.otpForm.value.mobile_number)
      this.api.forgotPassword(this.otpForm.value).subscribe((response:any)=>{
        console.log("after forgot password ",response);
        if(response.status=="1"){
          this.presentToast1(response.message)
        }
      //   {
      //     "status": "1",
      //     "message": "Otp has been sent to your registered mobile"
      // }
        
      })
      
      
    }
  }
  submitForm3(){
    this.createPassword=true
    this.otp=false
    

  }
  submitFormVerify(){
    //this.createPassword=true
   // this.otp=false
   // let token_id=localStorage.getItem("token_id");

    if(this.registerForm.valid){
      console.log("data",this.registerForm.value);
      this.api.verifyPassword(this.registerForm.value).subscribe((response:any)=>{
        console.log("after verify password ",response);
        if(response.status=="1"){
          this.register=false,
          this.registration=true
          this.presentToast1(response.message)
          localStorage.setItem("token_id",response.token_id)
        }else{
          this.presentToast(response.message)
        }
       
      //   {
      //     "status": "1",
      //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
      //     "message": "Otp verified successfully!!"
      // }
        
      })
      
      
    }

  }

  submitFormVerify1(){
    // this.createPassword=true
   // this.otp=false
   // let token_id=localStorage.getItem("token_id");

    if(this.otpForm.valid){
      console.log("data",this.otpForm.value);
      this.api.verifyPassword(this.otpForm.value).subscribe((response:any)=>{
        console.log("after verify password ",response);
        if(response.status=="1"){
          this.otp=false,
          this.createPassword=true
          this.presentToast1(response.message)
          localStorage.setItem("token_id",response.token_id)
        }else{
          this.presentToast(response.message)
        }
       
      //   {
      //     "status": "1",
      //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
      //     "message": "Otp verified successfully!!"
      // }
        
      })
      
      
    }

  }

  savePassword(){
    let token_id=localStorage.getItem("token_id");
    

    if(this.newPasswordForm.valid){
      this.newPasswordForm.patchValue({
      'token_id':token_id
    })
      console.log("data",this.newPasswordForm.value);
      let newData={username:localStorage.getItem("mobile"),password:this.newPasswordForm.value.new_password}
      this.api.savePassword(this.newPasswordForm.value).subscribe((response:any)=>{
        console.log("after password save",response);
        if(response.status=="1"){
         // this.newPasswordForm.value.new_password
          
          console.log("post for forgot password",newData);
          let enscrypted=this.encryptUsingAES256(JSON.stringify(newData))
          console.log("encrypted : ", enscrypted.ciphertext.toString(CryptoJS.enc.Base64))
          let data={data:enscrypted.ciphertext.toString(CryptoJS.enc.Base64)}
          this.api.forgot_password(data).subscribe((response:any)=>{
            console.log("updated",response);
            
          })
          
          
          this.presentToast1(response.message)
          this.login=true
          this.createPassword=false
          //localStorage.setItem("token_id",response.token_id)
        }else{
          this.presentToast(response.message)
        }
      //   {
      //     "status": "1",
      //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
      //     "message": "Otp verified successfully!!"
      // }

    //   {
    //     "status": "1",
    //     "message": "Your password has been updated successfully!!"
    // }

      })
    }

  }

  signup(){

    this.login=false
    this.register=true;

  }
  sendRegisterOtp(){

    
    if(this.registerForm.valid){
      console.log("data",this.registerForm.value);
      localStorage.setItem("mobile",this.registerForm.value.mobile_number)
      this.api.sendOtp(this.registerForm.value).subscribe((response:any)=>{
       // console.log("after forgot password ",response);
        this.presentToast(response.message)
        if(response.status=="1"){
          this.presentToast1(response.message)
          this.otpNumberRegister=true
         // this.login=true
          //this.createPassword=false
          //localStorage.setItem("token_id",response.token_id)
        }else{
          this.presentToast1("You are already Registered!")
          this.login=true
    this.register=false;

        }
      //   {
      //     "status": "1",
      //     "message": "Otp has been sent to your registered mobile"
      // }
        
      },
      error => {
        this.presentToast1("You are already Registered!")
          this.login=true
    this.register=false;
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      })
      
      
    }

  }

  submitRegisterVerify(){
   // this.createPassword=true
    //this.otp=
    //this.register
   // let token_id=localStorage.getItem("token_id");

    if(this.registerForm.valid){
      console.log("data",this.otpForm.value);
      this.api.verifyPassword(this.registerForm.value).subscribe((response:any)=>{
        console.log("after verify password ",response);
        if(response.status=="1"){
          this.presentToast1(response.message)
          localStorage.setItem("token_id",response.token_id)
          this.register=false
          this.registration=true;
        }else{
          this.presentToast(response.message)
        }
       
      //   {
      //     "status": "1",
      //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
      //     "message": "Otp verified successfully!!"
      // }
        
      })
      
      
    }

  }

  registerSubmit(){

    this.registrationForm.patchValue({
            'mobile':localStorage.getItem("mobile"),
          "token_id":localStorage.getItem("token_id")})

    if(this.registrationForm.valid){
      

      
console.log("data",this.registrationForm.value);
      this.api.registersubmit(this.registrationForm.value).subscribe((response:any)=>{
        console.log("after registration submit ",response);

        if(response.status=="1"){
          this.presentToast1(response.message)
         // localStorage.setItem("token_id",response.token_id)
        //  this.register=false
          this.registration=false;
          this.login=true
        }else{
          this.presentToast(response.message)
        }
       
      //   {
      //     "status": "1",
      //     "token_id": "TmRZZ2RRdzdaNGs3Tmg2bzdjYnFEd2lIOEFiMUpPTjdzYzBjTHJ1Wg==",
      //     "message": "Otp verified successfully!!"
      // }
        
      })
      
      
    }

  }

  
    
  
  async presentToast(message:any) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: 'danger',
      buttons: [
        {
          text: 'OK',
          cssClass: "toast-scheme",
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    toast.present();
  }
  async presentToast1(message:any) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: 'success',
      buttons: [
        {
          text: 'OK',
          cssClass: "toast-scheme",
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    toast.present();
  }

      
  submitdata() {


   // let data = JSON.stringify(this.user)
    this.api.login(this.user).subscribe((response: any) => {
      console.log('1', response);
      if(response.status=='failed'){
        this.message=true;
        this.message_text=response.message;
      }else if(response.status=='success'){
         sessionStorage.setItem('loginData', JSON.stringify(response));
        this.router.navigate(['/show-company-list']).then(() => {
          window.location.reload();
        });
      }
    });
  }
  //   console.log("test", this.user);
  //  // this.api.post(this.user.username, this.user.password)
  //     .subscribe((response: any[]) => {
  //       alert(response);
  //       console.log("response",response);
  //       sessionStorage.setItem('loginData',JSON.stringify(response));

  //       this.router.navigate(['/tabs/tab1'])
  //     }, (error) => {
  //       console.log('error from service', error);
  //       if (error.status == 401) {
  //         console.log("invalid credentials..!");



}
