import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from "rxjs";
import { LoadingController } from '@ionic/angular';

@Injectable({ providedIn: 'any'})

export class ApiService {
  session: any = {};
  public mainURL = "https://api.esarwa.com/api/";
  // public mainURL = "http://43.204.106.98:8000/api/";
  public esarwa_url="https://esarwa.com/for_api/Esarwa_Api/public/";
  app_version: any;
  //public select= "http://43.204.106.98:8000/api/getitem/";


  constructor(public http: HttpClient,public loadingCtrl:LoadingController) { }

  public async showLoading() {
    const loading = await this.loadingCtrl.create({
      message: 'Authenticating',
      duration: 2000,
      spinner:"lines-sharp-small"
    });
    
    loading.present();
  }

  public login(myString: any): Observable<any> {
    //console.log(myString);
    return this.http.post(this.mainURL + 'login/', myString)
  }
  public forgot_password(plaintext:any):Observable<any>{
    return this.http.post(this.mainURL + 'forgot_password/', plaintext)
  }

  public getHeader() {
    this.session = sessionStorage.getItem('loginData');
    let rowsession = JSON.parse(this.session);
    if (this.session != null) {
      //console.log("you can access header");
      let header = new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': 'Bearer ' + rowsession['token']
      })
     // //console.log(rowsession['token']);
      let options = { headers: header };
      return options
    }
  }
  
  public submitPayment(data:any): Observable<any> {
    let options = this.getHeader();
    return this.http.post(this.mainURL+'create_paytm_ac/',data,options)

  }
    
public getLedgerData(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  let body = company.id
  return this.http.post(this.mainURL + 'get_ledger_data/'+body+'/', company, header)
}
  public submitInvoicetemplate(theme_id:any){
    let options = this.getHeader();
    let id=this.getCompanyId();
    let data={theme: theme_id}
    return this.http.post(this.mainURL+'selectedtheme/'+id,data,options)
  }
  public getCompanyData(id:any): Observable<any> {
    let options = this.getHeader();
   // let id=this.getCompanyId();
    return this.http.post(this.mainURL + 'company/', {id:id}, options)
  }

  public post(myString: any): Observable<any> {
    return this.http.post('https://api.esarwa.com/api/login/', myString);
  }

  public createNewCompany(company: any, header: any): Observable<any> {
    //console.log(" data recieving from function", company);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'create_company/', company, header)

  }

  public getCompany(header: any) {
    //console.log('inside get company');
    let user_number = sessionStorage.getItem('loginData');
    this.session = sessionStorage.getItem('loginData');
    let rawSession = JSON.parse(this.session)
    //console.log(rawSession['mobile']);
    return this.http.post(this.mainURL + 'create_company/' + rawSession['mobile'], header)
  }

  public companyList(): Observable<any> {

    this.session = JSON.parse(sessionStorage.getItem("loginData"));
    let options = this.getHeader();
    //console.log("session", this.session);

    let rawSession = JSON.parse(this.session);
    //console.log("jjj", rawSession)
    return this.http.post(this.mainURL + 'selectbusiness/' + rawSession.user[0].mobile, null, options)
  }
  public selectedCompanyList(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    let body = { id: id };
    return this.http.post(this.mainURL + 'company/', body, header)
  }
  public createNewParty(party: any, header: any): Observable<any> {
    //console.log(" data recieving from function", party);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'party/', party, header)

  }
  public selectedPartyList(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    let body = { "company_id": id };
    return this.http.post(this.mainURL + 'getparty/', body, header)
  }

  public editParty(data: any, header: any): Observable<any> {
    //console.log(" data recieving from function", data);
    // let body={id:id};
    return this.http.put(this.mainURL + 'party_edit/', data, header)
  }
  public createNewItem(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'item/', item, header)
  }
  public selectedItemList(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    // let body={"id":id};
    return this.http.post(this.mainURL + 'getitem/', id, header)
  }
  public getSelectedItem(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    let body = { item: id };
    return this.http.post(this.mainURL + 'particularitem/', body, header)
  }

  public editItem(data: any, header: any): Observable<any> {
    //console.log(" data recieving from function", data);
    // let body={id:data};
    return this.http.put(this.mainURL + 'edit_item/', data, header)
  }
  public createNewBank(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'bank/', item, header)
  }
  public bankList(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
     let body={"company_id":id};
    return this.http.post(this.mainURL + 'getbank/', body, header)  
  }
  public getSelectedBank(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'getbankd/', id, header)
  }
  public editBank(data: any, header: any): Observable<any> {
    //console.log(" data recieving from function", data);
    //let body={"bank_id":data.id};
    return this.http.put(this.mainURL + 'edit_bank/', data, header)
  }

  // public deleteBank(data: any, header: any): Observable<any> {
  //   //console.log(" data recieving from function", data);
  //   return this.http.delete(this.mainURL + 'bankd/', data, header)
  // }
  public createNewSatff(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'staff/', item, header)
  }
  public createNewSatffOTP(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'enter_otp/', item, header)
  }

  public staffList(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'getstaff/' + id, null, header)
  }
  public editStaff(data: any, header: any): Observable<any> {
    //console.log(" data recieving from function", data);
    let body = data.id
    return this.http.put(this.mainURL + 'staffEdit/' + body, data, header)
  }
  public createNewLedger(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'create_ledger/', item, header)
  }
  public ledgerList(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    let body = { "company": id };
    return this.http.post(this.mainURL + 'getledger/', body, header)
  }

  public createLedgerCategory(): Observable<any> {
    // //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'ledger_under/', null)
  }

  public editLedger(data: any, header: any): Observable<any> {
    //console.log(" data recieving from function", data);
    let body = data.id
    return this.http.put(this.mainURL + 'update_ledger/' + body + '/', data, header)
  }

  public createCashLedger(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'cash/', item, header)
  }

  public cashLedgerList(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    // let body={ "company":id};
    return this.http.post(this.mainURL + 'getcash/', id, header)
  }
  public editCashLedger(data: any, header: any): Observable<any> {
    //console.log(" data recieving from function", data);
    // let body=data.id
    return this.http.put(this.mainURL + 'editcash/', data, header)
  }
  public createReceivedFor(): Observable<any> {
    // //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'recieved_for/', null)
  }
  public createPaymentIn(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'payment_in/', item, header)
  }

  public createPaymentOut(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'payment_out/', item, header)
  }

  public createInvoice(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'create_invoice/', item, header)
  }
  public receivedGST(header): Observable<any> {
    return this.http.post(this.mainURL + 'gst/', null)
  }

  public receivedUnit(): Observable<any> {
    return this.http.post(this.mainURL + 'unit/', null)
  }
  public receivedState(): Observable<any> {
    return this.http.post(this.mainURL + 'placeofsupply/', null)
  }
  public listIndustryType(): Observable<any> {
    return this.http.post(this.mainURL + 'industry_type/', null)
  }
  public listBusinessType(): Observable<any> {
    return this.http.post(this.mainURL + 'business_type/', null)
  }
  public salesRegister(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body = item.companyId
    return this.http.post(this.mainURL + 'sales_register/' + body, item, header)

  }
  public purchaseRegister(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body = item.companyId
    return this.http.post(this.mainURL + 'purchase_register/' + body, item, header)

  }

  public itemWiseSales(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body = { company: item };
    return this.http.post(this.mainURL + 'item_wise_sales/', body, header)

  }
  public itemWisePurchase(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let body=item.company
    let body = { company: item };
    return this.http.post(this.mainURL + 'item_wise_purchase/', body, header)

  }
  public partywisePurchase(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let body=item.company
    let body = { company: item };
    return this.http.post(this.mainURL + 'party_wise_purchase/', body, header)

  }
  public partywiseSales(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let body=item.company
    let body = { company: item };
    return this.http.post(this.mainURL + 'party_wise_sales/', body, header)
  }

  public billwiseProfit(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    // let body=item.company
    // let body = { company: item };
    return this.http.post(this.mainURL + 'bill_wise_profit/', item, header)
  }

  public partywiseItemPurchase(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'party_wise_item_purchase/', item, header)
  }

  public partywiseItemSales(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'party_wise_item_sales/', item, header)
  }

  public getexpenseCategory(a:any,header:any): Observable<any> {
    let body ={company_id : a}
    return this.http.post(this.mainURL + 'get_expense_category/',body,header)
  }

  public createNewExpenseCategory(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'exp/', item, header)
  }

  public createNewExpense(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'create_expense/', item, header)
  }

  public createJournalVoucher(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'create_voucher/', item, header)
  }
  public getPaidReceived(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body = item.company
    return this.http.post(this.mainURL + 'paid_received/' + body + '/', item, header)
  }
  
  public selectedCashLedger(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body={"company_id":item.company_id}
    return this.http.post(this.mainURL + 'getcash/', body, header)
  }

  public invoicePDF(item: any, header: any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.get(this.mainURL + 'create_pdf/'+item+'/', header)
  }
  
  public getJVLedger(item:any , header:any): Observable<any> {
    //console.log(" data recieving from function", item);
    return this.http.post(this.mainURL + 'getJVledgers/', item, header)
  }
  public categoryReport(item:any , header:any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body= item.company_name
    return this.http.post(this.mainURL + 'expense_report/'+body, item, header)
  }
  public postData(data,apiurl){
    // //console.log(data);
    // let url = this.baseUrl+"/"+apiurl;
    let baseUrl="https://esarwa.com/for_api/Esarwa_Api/public/";
    let url = baseUrl+apiurl;
    return this.http.post(url,data,
      {headers:new HttpHeaders({"content-type":"application/json"})});
  }

  public getData(apiurl){
    // let url = this.baseUrl+"/"+apiurl;
    let baseUrl="https://esarwa.com/for_api/Esarwa_Api/public/";
    let url = baseUrl+apiurl;
    return this.http.get(url,
      {headers:new HttpHeaders({"content-type":"application/json"})});
  }
  
  public viewBankLedger(item:any , header:any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body= item.bank_id
    return this.http.post(this.mainURL + 'get_bank_ledger/'+body+'/', item, header)
  }
  
  public viewCashLedger(item:any , header:any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body= item.bank_id
    let comp = item.company_name
    return this.http.post(this.mainURL + 'get_cash_ledger/'+body+'/'+comp, item, header)
  }
  
  public editCompany(item:any , header:any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body= item.id
    return this.http.put(this.mainURL + 'company/'+body, item, header)
  }
  
  public getParticularInvoice(item:any , header:any): Observable<any> {
    //console.log(" data recieving from function", item);
   return this.http.post(this.mainURL + 'get_particular_invoice/', item, header)
  }
  
  public expenseCategoryReport(item:any , header:any): Observable<any> {
    //console.log(" data recieving from function", item);
    let body= item.category_id
   return this.http.post(this.mainURL + 'expense_report_data/'+body+'/', item, header)
  }
  
  public ledgerReport(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    let body = { "company_id": id };
    return this.http.post(this.mainURL + 'display_ledger_report/', body, header)
  }
  public paymentGateway(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'create_paytm_ac/', id, header)
  }
  public editParticularInvoice(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.put(this.mainURL + 'update_invoice/', id, header)
  }
  public gstr2(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'purchase_reg_gstr/', id, header)
  }
  public gstr3Sales(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'sales_reg_gstr/', id, header)
  }
  public gstr3Purchase(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'purchase_reg_gstr/', id, header)
  }
  
  public getParticularParty(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    let body={party_id:id}
    return this.http.post(this.mainURL + 'particular_party/', body, header)
  }
  public getDashboard(company: any): Observable<any> {
    let header=this.getHeader();
    //console.log(" data recieving from function", company);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'dashboard_data/', company, header)

  }
  public defaultDate(): Observable<any> {
    let header=this.getHeader();
    return this.http.post(this.mainURL + 'get_default_date/',header)

  }
  
  public paymentMode(): Observable<any> {
    let header=this.getHeader();
    return this.http.post(this.mainURL + 'payment_mode/',header)
 }
  
  public partyTransaction(id: any, header: any): Observable<any> {
    //console.log(" data partyTransaction ", id);
    let body=id.party
    return this.http.post(this.mainURL + 'get_party_ledger/'+body+'/', id, header)
  }
  
  public getParticularPayment(id: any, header: any): Observable<any> {
    //console.log(" data partyTransaction ", id);
    let body=id.id
    return this.http.post(this.mainURL + 'particular_payment/'+body, id, header)
  }
  
  public editPaymentOut(id: any, header: any): Observable<any> {
    //console.log(" data partyTransaction ", id);
    let body=id.pk
    return this.http.put(this.mainURL + 'edit_payment_out/'+body+'/', id, header)
  }
    
  public editPaymentIn(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    let body=id.pk
    return this.http.put(this.mainURL + 'edit_payment_in/'+body+'/', id, header)
  }
  
  public particularExpenseData(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    // let body=id.id
    return this.http.post(this.mainURL + 'particular_expense/', id, header)
  }
  
  public editExpense(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.put(this.mainURL + 'edit_expense/', id, header)
  }  
public gstr1B2CLarge(id: any, header: any): Observable<any> {
    //console.log(" data recieving from function", id);
    return this.http.post(this.mainURL + 'gst1_b2c_large/', id, header)
  }
  public gstr1B2B(company: any, header:any): Observable<any> {
    //console.log(" data recieving from function", company);
    // let testData={ business_name:"test name"};
    return this.http.post(this.mainURL + 'gst1_b2b/', company, header)
}
public gstr1B2CSmall(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'gst1_b2c_small/', company, header)
}
public gstr1CreaditNoteR(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'gst1_cn_reg/', company, header)
}
public gstr1CreaditNoteU(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'gst1_cn_unreg/', company, header)
}
public gstr1NilRated(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'nil_rated/', company, header)
}
public gstr1DocSummary(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'document_summary/', company, header)
}
public gstr1HSNSummary(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'hsn_summary/', company, header)
}
public trailBalance(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'trial_balance/', company, header)
}
public trailBalanceData(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'trial_balance_data/', company, header)
}
public particularTrailBalance(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  // let testData={ business_name:"test name"};
  return this.http.post(this.mainURL + 'trial_balance_details/', company, header)
}
public getInvoiceNo(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
   let body={ company: company};
  return this.http.post(this.mainURL + 'invoice_prefix/', body, header)
}

public exportSalesRegister(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
   let body=company.companyId
  return this.http.post(this.mainURL + 'sales_register_excel/'+body, company, header)
}
public exportBillwiseProfit(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  return this.http.post(this.mainURL + 'bill_profit_excel/', company, header)
}
public exportItemWiseSales(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  let body={company: company}
  return this.http.post(this.mainURL + 'item_sales_excel/', body, header)
}
// public exportPartywiseSales(company: any, header:any): Observable<any> {
//   //console.log(" data recieving from function", company);
//   return this.http.post(this.mainURL + 'party_sales_excel/', company, header)
// }
public exportPurchaseRegister(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
   let body=company.companyId
  return this.http.post(this.mainURL + 'purchase_register_excel/'+body, company, header)
}
public exportItemWisePurchase(company: any, header: any): Observable<any> {
  let body = { company: company }
  return this.http.post(this.mainURL + 'item_purchase_excel/', body, header)
}
public exportPartywisePurchase(company: any, header: any): Observable<any> {
  let body = { company: company }
  return this.http.post(this.mainURL + 'party_purchase_excel/', body, header)
}
public exportPartywiseSales(company: any, header: any): Observable<any> {
  let body = { company: company }
  return this.http.post(this.mainURL + 'party_sales_excel/', body, header)
}
// public exportItemWisePurchase(company: any, header:any): Observable<any> {
//   //console.log(" data recieving from function", company);
//   return this.http.post(this.mainURL + 'party_purchase_excel/', company, header)
// }
// public exportPartywisePurchase(company: any, header:any): Observable<any> {
//   //console.log(" data recieving from function", company);
//   return this.http.post(this.mainURL + 'item_purchase_excel/', company, header)
// }
public exportGstr1(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  return this.http.post(this.mainURL + 'gstr1_excel/', company, header)
}
public exportGstr2(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  return this.http.post(this.mainURL + 'gstr2/', company, header)
}
public exportGstr3(company: any, header:any): Observable<any> {
  //console.log(" data recieving from function", company);
  return this.http.post(this.mainURL + 'gstr3/', company, header)
}
public getCompanyId(){
  let company_id=JSON.parse(sessionStorage.getItem("currentCompany"));
  return company_id[0].id;
}
public forgotPassword(data:any){
    // let header = new HttpHeaders({
    //   'Content-type': 'application/json'
    // })
    return this.http.post(this.esarwa_url+'forget_password',data,{headers:new HttpHeaders({"content-type":"application/json"})})
  }

  public verifyPassword(data:any){
    return this.http.post(this.esarwa_url+'verify_otp',data,{headers:new HttpHeaders({"content-type":"application/json"})})
  }

  public savePassword(data:any){
    return this.http.post(this.esarwa_url+'new_password',data,{headers:new HttpHeaders({"content-type":"application/json"})})

  }

  public sendOtp(data:any){
    return this.http.post(this.esarwa_url+'mobile_otp',data,{headers:new HttpHeaders({"content-type":"application/json"})})
  }

  public registersubmit(data:any){
    return this.http.post(this.esarwa_url+'register_user',data,{headers:new HttpHeaders({"content-type":"application/json"})})
  }

  public fakeData(data:any){
    return this.http.get("https://reqres.in/api/users?page="+data)
  }

  
 
}



