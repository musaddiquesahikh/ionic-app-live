import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import { AlertController, ModalController, NavController, PopoverController, ToastController } from '@ionic/angular';
import { ApiService } from "../api.service";
import { EditCompanyPage } from '../edit-company/edit-company.page';
import { Vibration } from '@awesome-cordova-plugins/vibration/ngx';
import { PaymentOutPage } from '../payment-out/payment-out.page';
import { LanguageService } from '../language.service';
import { TranslateService } from '@ngx-translate/core';
import { PermissionGuard } from '../guards/permission.guard';
import { Location } from '@angular/common';



@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
  @ViewChild(RouterOutlet) outlet: RouterOutlet;
  trigger_button: boolean
  trigger_button1: boolean
  data: any = [];
  item: any = [];
  jou: boolean;
  listCompany: any = [];
  companyList: any = []
  latestCompany1: any = [];
  latestCompany: any
  cash_balance: any;
  bank_balance: any;
  recent_transcation: any;
  companyId: any;
  canDismiss: any;
  currentCompanyId: any;
  role: any;
  languages: any = []
  selected: any = ''
  weeklysales: any;
  currentCompany: any = [];
  isModalOpen: any;
  contentId: any;

  constructor(public modalCtrl: ModalController, private router: Router, public api: ApiService, public navCtrl: NavController,
    private vibration: Vibration, public toastController: ToastController, public alertCtrl: AlertController,
    private popOverCtrl: PopoverController, private languageService: LanguageService, private translate: TranslateService,
    public permission:PermissionGuard, public location: Location) {

  }


  ngOnInit() {
    this.languages = this.languageService.getLanguage()
    this.selected = this.languageService.selected
    this.dashboadOnload();
    this.trigger_button = false
    // this.latestCompany1 = JSON.parse(sessionStorage.getItem("currentCompany"))
    // console.log("current",this.latestCompany1[0].business_name);
    // this.latestCompany = this.latestCompany1[0].business_name;
  }

  click(){
    this.router.navigate(['/create-new-item'])

  }

  dashboadOnload() {
    let company = this.api.getCompanyId()
    let options = this.api.getHeader()
    this.languages = this.languageService.getLanguage()
    this.selected = this.languageService.selected
    // this.dashboadOnload();
    this.trigger_button = false

    this.api.getWeeklySales(company, options).subscribe((response: any) => {
      this.weeklysales = response
      console.log("response from weekly sales", response);
    })
    let user = JSON.parse(sessionStorage.getItem('loginData'));
    let r = { "mobile_no": user.user[0].mobile, "company": this.api.getCompanyId() }
    this.api.role(r).subscribe((response: any) => {
      console.log("respkkk", response.data.role);
      this.role = response.data.role
    })

    this.jou = false;

    if (sessionStorage["loginData"] == null) {
      console.log("Please Login");
      this.router.navigate(['/login'])
    } else {
      console.log("else work");

      this.listCompany = JSON.parse(sessionStorage.getItem("listCompany"))
      this.companyList = JSON.parse(sessionStorage.getItem("companyList"))
      this.companyId = this.api.getCompanyId();
      this.latestCompany1 = JSON.parse(sessionStorage.getItem("currentCompany"))
      console.log("current", this.latestCompany1[0].business_name);
      this.latestCompany = this.latestCompany1[0].business_name;
      this.currentCompanyId = this.latestCompany1[0].id
      this.getdashboarddata();

      this.api.getReceivedFor().subscribe((response: any) => {
        //console.log(response);
        localStorage.setItem('ledgerCategory', JSON.stringify(response.Data));
        /// console.log("ledgerCategory", response.Data);

      });
      let a = JSON.parse(sessionStorage.getItem("currentCompany"))
      let company_Id = a[0].id
      console.log("this.currentCompanyId", company_Id);

      this.api.getSubscription1(company_Id).subscribe(async (response: any) => {
        console.log("getSubscription123", response);
      })
    }
  }

  journal() {
    this.jou = true;
  }
  saveItem() { }

  modelDismiss() {
    this.modalCtrl.dismiss();
  }

  appLogout() {
    this.modalCtrl.dismiss();
    sessionStorage.removeItem("loginData");
    sessionStorage.removeItem("listCompany");
    sessionStorage.removeItem("companyList");
    sessionStorage.removeItem("currentCompany");
    // this.modalCtrl.dismiss();
    this.router.navigate(['/login']).then(() => {
      // window.location.reload();
    });
    // this.modalCtrl.dismiss();
    this.trigger_button = false
  }
  getdashboarddata() {
    let company = this.companyId;
    // console.log("company -->", company);

    this.api.getDashboard({ company: company }).subscribe((response: any) => {
      // console.log("ggglkhjhg", response);
      this.bank_balance = response.data.bank_balance
      this.cash_balance = response.data.cash_balance
      this.recent_transcation = response.recent_transactions.slice(0, 5)
    });
  }

  putCurrent(data) {
    let dd = JSON.stringify([data])
    sessionStorage.setItem("currentCompany", dd);
  }
  modal() {
    console.log("button");
    this.trigger_button = true
  }
  modal1() {
    console.log("button");
    this.trigger_button1 = true
  }

  selectCompany(data) {
    // this.putCurrent(data);
    this.item = [data];
    //console.log("received", this.item);
    sessionStorage.setItem('currentCompany', JSON.stringify(this.item))
    this.navCtrl.navigateRoot('empty')
    this.trigger_button = false
    this.modalCtrl.dismiss()
  }
  ionViewWillEnter() {
    this.dashboadOnload();

    console.log("page called");

  }
  dismissmodal(ev) {
    this.modalCtrl.dismiss();
    this.trigger_button = false
    this.canDismiss = ev.detail.select;
  }
  async editCompany(item) {
        const modal = await this.modalCtrl.create({
          component: EditCompanyPage,
          cssClass: 'my-custom-class',
          componentProps: {
            item: item
          }
        });
        modal.onDidDismiss()
        .then((data: any = {}) => {
          const user = data.data; // Here's your selected user!
            console.log("from address ", user)
            this.dashboadOnload();
          });
        // this.parentFunction.emit(this.item);
        // console.log("selected company", item)
        return await modal.present();
      }
  doRefresh($event) {
    // console.log("refreshed");
    this.getdashboarddata();
    $event.target.complete();

  }
  vibrate() {
    // this.vibration.vibrate(100);
  }

  async paymentIn() {
    this.dashboadOnload();
    if (this.role == "salesman") {
      let alert = await this.alertCtrl.create({
        header: 'Unauthorized',
        message: 'You are not authorized to visit that page!',
        buttons: ['OK']
      });
      alert.present();

    } else {
      // this.router.navigate['/payment-in-out']
      // this.router.navigate(['/payment-in-out'])
      this.router.navigateByUrl('/payment-in-out')
      // const modal = await this.modalCtrl.create({
      //   component: PaymentInOutPage,
      //   cssClass: 'my-custom-class',
      // });
      // modal.onDidDismiss()
      //   .then((data: any = {}) => {
      //     const user = data.data; // Here's your selected user!
      //     console.log("from address 989 ", user)
      //     this.dashboadOnload();
      //   });
      // return await modal.present();
    }
  }
  async paymentOut() {
    if (this.role == "salesman") {
      let alert = await this.alertCtrl.create({
        header: 'Unauthorized',
        message: 'You are not authorized to visit that page!',
        buttons: ['OK']
      });
      alert.present();

    } else {
      const modal = await this.modalCtrl.create({
        component: PaymentOutPage,
        cssClass: 'my-custom-class',
      });
      modal.onDidDismiss()
        .then((data: any = {}) => {
          const user = data.data; // Here's your selected user!
          console.log("from address 989 ", user)
          this.dashboadOnload();
        });
      return await modal.present()
    }
  }
  select(lng) {
    console.log("ppppp", lng);
    this.languageService.setLanguage(lng)
    this.modalCtrl.dismiss()
  }


}
