import { modalController } from '@ionic/core';
import { Location } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController,ToastController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { ApiService } from '../api.service';
import { PermissionGuard } from '../guards/permission.guard';

@Component({
  selector: 'app-invoice-setting',
  templateUrl: './invoice-setting.page.html',
  styleUrls: ['./invoice-setting.page.scss'],
})
export class InvoiceSettingPage implements OnInit {
  @Output() invoiceSFunction: EventEmitter<any> = new EventEmitter();
  sett: any = {
    extra_fields:[]
  }
  extraF: any=[];
  formValue: boolean=false;
  prefix12:boolean
  has_suffix:boolean
   constructor(public api: ApiService, public toastController: ToastController, public router: Router,private location:Location,
    public modal: ModalController, private translate: TranslateService, private permission: PermissionGuard, private alertCtrl: AlertController,
  )  { }

  ngOnInit() {
    this.show();
    this.invPrefix();
  }
   dismis() {
    modalController.dismiss()
  }
  show() {
    console.log("showcomponent");
    console.log(this.sett.prefix, this.sett.has_suffix,"checked");

      let company = this.api.getCompanyId()
        this.api.post3('get_invoice_settings/', { "company": company, "type": 1 }).subscribe((response: any) => {
        this.sett = response
        console.log(response, 'setting');
        console.log(JSON.parse(response.extra_fields),'after parse');
        this.extraF=JSON.parse(response.extra_fields)
        console.log(this.extraF.length,'after parse');
        if (this.sett.has_suffix == true) {
          this.sett.has_suffix=true
        }
        if (this.sett.prefix12==true) {
          this.sett.prefix12 = true;
        } 
        if (this.sett.is_sequence == true) {
          this.sett.prefix12 = true
        }
        if(this.extraF.length!=0){
          this.formValue = true
        }
        if (this.sett.po_number == false) {
          this.sett.po_number = true
        } else {
          this.sett.po_number = true
        }
        if (this.sett.eway_number == false) {
          this.sett.eway_number = false
        } else {
          this.sett.eway_number = true
        }
        if (this.sett.vehicle_number == false) {
          this.sett.vehicle_number = false
        } else {
          this.sett.vehicle_number = true
        }
      })
   

    }
  invPrefix() {
    // this.prefix12=!this.prefix12
    if (this.sett.prefix12==false) {
      this.sett.prefix = null;
    } 
    else{
      this.prefix12 =true
    }
 
  }
  toggleShow1(){
    console.log(this.sett.has_suffix);

    if(this.sett.has_suffix==false){
      this.sett.suffix=""
    }
  }
  ClickNewRow() {
    let sett={
      extra_fields:""
    }
    this.extraF.push(sett)
    this.formValue = true
  }

  deleteRow1(i:number){
    this.extraF.splice(i,1)
   }
   Submit(sett: any) {
    console.log(sett,"sett");
    
    sett.extra_fields=this.extraF
    this.invoiceSFunction.emit(sett);
    
  }
   addExtraFeild() {
    this.sett.extra_fields=this.extraF

    let company = this.api.getCompanyId()
    if (this.prefix12 == true) {
      
      this.sett.is_sequence=true
    }else{
      this.sett.is_sequence=false
    }
    this.api.post3('invoice_settings/', { "company": company, "type": 1,po_number:this.sett.po_number,
    eway_number:this.sett.eway_number,vehicle_number:this.sett.vehicle_number,prefix:this.sett.prefix,suffix:this.sett.suffix,has_suffix:this.sett.has_suffix,annual_reset:this.sett.annual_reset,extra_fields:this.sett.extra_fields,
    is_sequence:this.sett.is_sequence,id:this.sett.id,}).subscribe(async (response: any) => {
      console.log('response setting', response);
      if(response.status=="success"){
        const toast = await this.toastController.create({
          message: "Invoice setting updated successfully",
          duration: 2000,
          color: "warning"
        });
        toast.present();
      }
    })
    modalController.dismiss();
}
}
