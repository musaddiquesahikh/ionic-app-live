import { EWayPage } from './../e-way/e-way.page';
import { InvoiceSettingPage } from './../invoice-setting/invoice-setting.page';
import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController, NavController, ToastController } from '@ionic/angular';
import { modalController } from '@ionic/core';
import { TranslateService } from '@ngx-translate/core';
import { ApiService } from '../api.service';
import { PermissionGuard } from '../guards/permission.guard';

@Component({
  selector: 'app-invoice-beta',
  templateUrl: './invoice-beta.page.html',
  styleUrls: ['./invoice-beta.page.scss'],
})

export class InvoiceBetaPage implements OnInit {
  @ViewChild('segment') segment: any; company: any = {};
  @Input() invoice_type1
  exp1: any = []
  prefix: boolean
  invoiceID: any
  exp: any = []
  invoice_type = 1;
  poNo: boolean
  addF: boolean
  vehicleNo: boolean
  ewayNo: boolean
  subTotal: number
  total_amount: number
  received_amt: number
  discountTotal:number
  addCharge: boolean
  invoice_model: any = {
    invoice_no: "",
    invoice_date: "",
    payment_terms: 30,
    due_date: "",
    total_amount: 0,
    discount: 0,
    discountTotal:0,
    received_amt: 0,
    receivable: 0,
    partial_paid: 0,
    party: 0,
    taxable_amount: 0,
    invoice_type: 1,
    payment_status: 1,
    company_name: 14,
    extra_fields: [],
    items: [{
      units: []
    }],
    place_of_supply: 1,
  }
  invSett: any = []
  dictionary: any = [{
    "type": "1",
    "header": this.translate.instant('HEADER.SALES INVOICE'),
    "label": this.translate.instant('HEADER.SALES INVOICE NO'),
    "sButton": this.translate.instant('HEADER.SAVE INVOICE'),
    "gButton": "Generate Bill"
  },
  {
    "type": "2",
    "header": this.translate.instant('HEADER.PURCHASE INVOICE'),
    "label": this.translate.instant('HEADER.PURCHASE INVOICE NO'),
    "sButton": this.translate.instant('HEADER.SAVE PURCHASE INVOICE'),
    "gButton": "Generate Bill"

  },
  {
    "type": "3",
    "header": "Create Sales Return",
    "label": "Credit Note No",
    "sButton": this.translate.instant('HEADER.SAVE SALES RETURN'),
    "gButton": "Save & New"
  },
  {
    "type": "4",
    "header": "Create Purchase Return",
    "label": "Debit Note No",
    "sButton": this.translate.instant('HEADER.SAVE PURCHASE RETURN'),
    "gButton": "Save & New"
  },
  {
    "type": "5",
    "header": "Quotation",
    "label": "Quotation No",
    "sButton": this.translate.instant('HEADER.SAVE QUOTATION'),
    "gButton": "Save & New"
  },
  {
    "type": "6",
    "header": "Create Delivery Challan",
    "label": "Delivery Challan No",
    "sButton": this.translate.instant('HEADER.SAVE DELIEVERY CHALLAN'),
    "gButton": "Save & New"
  },
  {
    "type": "7",
    "header": this.translate.instant('HEADER.PROFORMA INVOICE'),
    "label": this.translate.instant('HEADER.INVOICE NO'),
    "sButton": this.translate.instant('HEADER.SAVE PROFORMA'),
    "gButton": "Save & New"
  },]

  showItemsPanel: Boolean = false

  providers: [DatePipe]

  items: any = []
  partyComponent: boolean = false;
  itemComponent: boolean = false;
  party_details: any = {};
  placeOf: any;
  total_taxable_amount: number;
  total_cess_rate: number;
  company_gst: any;
  totaltax: number;
  cgst: number = 0;
  sgst: number = 0;
  igst: number = 0;
  finalItem: any = [];
  submit: boolean;
  billId: any;
  downloadUrl: string;
  bank: any = [];
  finalAmount: number;
  noTax: Boolean = true;
  invoiceD: any;
  merchanTrans_id: any;
  payentStatusPOS: any = {};
  statusbutton: boolean = false;
  paymentDone: boolean = false;
  progressWheel: boolean = false;
  resendbutton: Boolean = false;
  itemEmitted: any;
  units: any;
  unit: any;
  u: any;
  toast: any;
  place: any;
  gst: boolean = false;
  place_of_supply: any;
  extraF: any = [];
  showInvoice: boolean;
  get: number;
  enableEInvoice: boolean = false;
  companyDetails: any;
  eInvoice: Boolean = false;
  warningParty: boolean;
  eWayBill: boolean = false;
  e: any;
  ewaybillDownload: boolean = false;
  vehicleDetails: boolean = false;
  vehicleSubmitted: any;
  sales_prices: number

  selectSegment = 'a';
  // a: boolean=true;
  // b: boolean=false;
  downloadEinvoiceButton: boolean = false;
  toggleitem: Boolean = true;
  partialPAid: number;
  receivable: number;
  charge: any;
  constructor(private cdr: ChangeDetectorRef, public api: ApiService, public datepipe: DatePipe, public toastController: ToastController, public router: Router,
    public modal: ModalController, private translate: TranslateService, private permission: PermissionGuard, private alertCtrl: AlertController,
    public location: Location, private navCtrl: NavController) { }

  ngOnInit() {

    this.invoice_head()
    this.partialPAid = 0;
    this.addCharge = false
    this.poNo = false
    this.ewayNo = false
    this.vehicleNo = false
    this.addF = false
    this.prefix = false
    this.invoice_model.received_amt = 0;
    this.total_amount = 0
    this.subTotal = 0;
    this.receivable = 0;
    this.invoice_model.discountTotal=0

    this.supply()
    console.log(this.companyDetails, "p");
    // console.log(this.companyDetails[0].pay_gateway_service);

    this.companyDetails = JSON.parse(sessionStorage.getItem('currentCompany'));
    // this.deleteLedger(i)
    if (this.companyDetails[0].einvoice_service = true) {
      this.enableEInvoice = true;
    }
    let companyDetails = JSON.parse(sessionStorage.getItem("currentCompany")).einvoice_service
    if (companyDetails == true) {
      this.eInvoice = true
    }

  }

  invoice_head() {
    console.log("call function");

    this.invoice_type = this.invoice_type1
    console.log(this.invoice_model);

    console.log(this.invoice_type, "prajakta");


    let companyDetails = JSON.parse(sessionStorage.getItem("currentCompany")).einvoice_service
    if (companyDetails == true) {
      this.eInvoice = true
    }
    this.companyDetails = JSON.parse(sessionStorage.getItem("currentCompany"));
    if (this.companyDetails[0].einvoice_service == true) {
      this.enableEInvoice = true;
    }
    else {
      this.enableEInvoice = false;
    }
    this.company_gst = this.companyDetails[0].gst_number
    let companyId = this.api.getCompanyId()
    let header = this.api.getHeader()
    this.invoice_model.invoice_type = this.invoice_type
    if (this.invoice_type == 1 || this.invoice_type == 3) {
      this.api.getInvoiceNo(companyId, header).subscribe((response: any) => {
        console.log(response, "prefix");

        if (response.status != 500) {
          // this.invoice_model.invoice_no = response.sales_invoice_no;
          this.invoice_model.invoice_no = response.invoice_settings.prefix + response.sales_invoice_no;

        }
      })
    }
    let company = this.api.getCompanyId()
    let a = this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 4 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7;
    if (this.invoice_type == 1) {
      this.api.post3('get_invoice_settings/', { "company": company, "type": Number(a) }).subscribe((response: any) => {
        this.invSett = response
        this.invSett.extra_fields = JSON.parse(response.extra_fields)

        console.log(response, 'setting');
      })
    }
    this.api.bankList(companyId, header).subscribe((response: any) => {
      if (response.status != 500) {
        this.bank = response
      }
    });
    let term = this.invoice_type;
    this.dictionary = this.dictionary.filter((dictionary) => {
      return dictionary.type.indexOf(term) > -1;
    });
    let today_date = Date.now();
    this.invoice_model.invoice_date = today_date
    this.dateChange()
  }
  invoiceSFunction(sett: any) {
    this.invSett = sett
    this.invoice_head()
  }

  getInvoiceSetting() {
    let company = this.api.getCompanyId()
    this.api.post3('get_invoice_settings/', { "company": company, "type": Number(this.invoice_type) }).subscribe((response: any) => {
      // console.log("response on invoice setting", response);

    })
  }
  dateChange() {
    // this.invoice_model.due_date = new Date(Date.now() + this.invoice_model.payment_terms * 24 * 60 * 60 * 1000)
    // this.invoice_model.invoice_date = this.datepipe.transform(this.invoice_model.invoice_date, 'yyyy-MM-dd')
    // this.invoice_model.due_date = this.datepipe.transform(this.invoice_model.due_date, 'yyyy-MM-dd')

    this.invoice_model.invoice_date = this.datepipe.transform(this.invoice_model.invoice_date, 'yyyy-MM-dd')
    var nextDay = new Date(this.datepipe.transform(this.invoice_model.invoice_date, 'yyyy-MM-dd'));
    nextDay.setDate(nextDay.getDate() + Number(this.invoice_model.payment_terms));
    this.invoice_model.due_date = this.datepipe.transform(nextDay, 'yyyy-MM-dd')
  }

  showPartyData() {
    this.partyComponent = true;
    if (this.partyComponent) {
      this.gst = true
    }
    else {
      this.gst = false
    }
  }
  showItemData() {
    this.itemComponent = true;
  }
  dismiss(index) {
    this.items.splice(index, 1);
    this.calculation()
  }
  async partyFunction(party: any) {
    console.log(party, "party");

    // console.log(this.enableEInvoice,);
    // if (this.enableEInvoice == true) {
    //   const toast = await this.toastController.create({
    //     message: party.Party_name + " " + this.translate.instant("MESSAGE.DOES NOT HAVE GSTIN"),
    //     // summary: this.translate.instant("MESSAGE.E-INVOICE CANNOT BE GENERATED"),
    //     duration: 3000,
    //     color: "warning"
    //   });
    //   toast.present();
    //   this.eInvoice = false
    // }


    if (party.c_party == false) {
      console.log("hide party");
      this.partyComponent = false;
    }
    this.party_details = party
    if (this.party_details.gstin == null) {
      // console.log(this.party_details,"sheeeetal");

      this.placeOf = this.party_details.gst_compare
      this.placeOf = this.placeOf.slice(0, 2)
      console.log(this.enableEInvoice,);
      if (this.enableEInvoice == true) {
        alert(this.party_details.Party_name + " " + this.translate.instant("MESSAGE.DOES NOT HAVE GSTIN")),
          this.eInvoice = false
      }
    } else {
      this.placeOf = this.party_details.gstin.slice(0, 2)
    }
    this.partyComponent = false
    this.showItemsPanel = true

    this.submit = true
    this.placeOf = this.party_details.gst_compare
    this.invoice_model.place_of_supply = Number(this.placeOf)
    if (this.invoice_model.place_of_supply < 10) {
      this.placeOf = "0" + this.invoice_model.place_of_supply.toString()
      console.log(this.placeOf, "ppppppp");
    }
    else {
      this.placeOf = this.invoice_model.place_of_supply.toString()
    }
    console.log(this.invoice_model.place_of_supply, "ppppppp");
    if (this.party_details.gstin != null) {
      console.log(this.eInvoice, "eInvoice");
      let f = JSON.parse(sessionStorage.getItem("currentCompany")).einvoice_service
      if (f == true) {
        if (this.eInvoice == false) {
          console.log(this.eInvoice, "eInvoice");
        }
      }
    }
    this.calculation();
    this.calculateTax();
    this.calculateGst();
  }

  parentFunction1(data: any) {
    console.log(data, 'from parent');
    if (data.c_party == undefined) {
      if (data.discount == null) {
        data.discount = 0;
      }

      if (data.c_party == false) {
        console.log("hide party");
        this.itemComponent = false;
      }
      this.items = this.items.concat(data);
      console.log(this.items)
      this.itemComponent = false
    }
    this.itemEmitted = data
    console.log(this.itemEmitted, 'emitted items');
    for (let t of this.items) {

      if (t.item_type == 1) {
        console.log(t.units, "units");
        if (t.units.length > 0) {
          console.log('inside if');
          let i = 0
          this.unit = this.items[i].units

          for (let s of t.units) {

            t.units[i].unit = t.units[i].unit.slice(0, 3)

            t.abc = t.units[0]
            i++;
            console.log(s.type);

          }
        }
        else {

          t.abc = { id: null, type: null, unit: null }
          console.log('inside else');

        }
      }
      else {
        t.abc = { id: null, type: null, unit: null }
      }

    }
    this.subTotal = this.total();
    this.total_taxable_amount = this.total_taxable();
    this.calculation();
  }
  unitChange(unit: any, i: any) {
    console.log(unit.type, "praj");
    if (unit.type == 1) {
      this.items[i].oldRate = this.items[i].rate;
      this.items[i].oldPurchaseRate = this.items[i].purchase_rate;
      this.items[i].rate = this.items[i].conversion_rate_sales;
      this.items[i].purchase_rate = this.items[i].conversion_rate_purchase;
    } else {
      this.items[i].rate = this.items[i].oldRate;
      this.items[i].purchase_rate = this.items[i].oldPurchaseRate;
    }
    this.calculation();
  }
  calculation() {
    let index = 0;
    for (let i of this.items) {
      if (i.Gst_tax_rate == -1) {
        this.items[index].sales_prices = (i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate)) + ((0 + i.cess_tax_rate) / 100 * ((i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate))))
        this.items[index].sales_prices = Math.round((this.items[index].sales_prices + Number.EPSILON) * 100) / 100
        this.items[index].purchase_prices = (i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate)) + ((0 + i.cess_tax_rate) / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
        this.items[index].purchase_prices = Math.round((this.items[index].purchase_prices + Number.EPSILON) * 100) / 100
      } else {
        this.items[index].sales_prices = (i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate)) + ((i.Gst_tax_rate + i.cess_tax_rate) / 100 * ((i.quantity * i.rate) - (i.discount / 100 * (i.quantity * i.rate))))
        this.items[index].sales_prices = Math.round((this.items[index].sales_prices + Number.EPSILON) * 100) / 100
        this.items[index].purchase_prices = (i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate)) + ((i.Gst_tax_rate + i.cess_tax_rate) / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
        this.items[index].purchase_prices = Math.round((this.items[index].purchase_prices + Number.EPSILON) * 100) / 100
      }
      this.items[index].cess = ((i.cess_tax_rate / 100 * ((i.rate * i.quantity) - (i.discount / 100 * (i.quantity * i.rate)))))
      if (i.Gst_tax_rate == -1) {
        this.items[index].sales_tax = 0
        this.items[index].purchase_tax = 0
      } else {
        this.items[index].sales_tax = (i.Gst_tax_rate / 100 * ((i.rate * i.quantity) - (i.discount / 100 * (i.quantity * i.rate))))
        this.items[index].purchase_tax = (i.Gst_tax_rate / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
      }

      this.items[index].cessp = (i.cess_tax_rate / 100 * ((i.quantity * i.purchase_rate) - (i.discount / 100 * (i.quantity * i.purchase_rate))))
      index++
    }


    this.total_taxable_amount = Math.round((this.total_taxable() + Number.EPSILON) * 100) / 100
    this.total_amount = Math.round(this.total() - ((this.invoice_model.discount * this.total()) / 100) + Number.EPSILON)

    // this.subTotal = (Math.round((((this.total() - (((this.invoice_model.discountTotal) * this.total()) / 100))) + Number.EPSILON) * 100) / 100)
    this.invoice_model.extra_charges_lst = Number(this.charge)
    // this.subTotal = Math.round((((this.total_amount + Number(this.invoice_model.extra_charges_lst))) + Number.EPSILON) * 100) / 100
    this.total_amount = Math.round((((this.total_amount + Number(this.invoice_model.extra_charges_lst))) + Number.EPSILON) * 100) / 100
    this.subTotal = (Math.round((((this.total() - (((this.invoice_model.discountTotal) * this.total()) / 100))) + Number.EPSILON) * 100) / 100)

    console.log(this.invoice_model.discount, this.total_amount, "receivable");

    this.totaltax = Math.round((this.calculateTax() + Number.EPSILON) * 100) / 100
    this.calculateGst()
    this.receivable = Math.round((((this.subTotal - this.invoice_model.received_amt)) + Number.EPSILON) * 100) / 100
    console.log(this.invoice_model.received_amt, "receivable");


    this.total_cess()
  }

  total_taxable() {
    let ff = 0;
    let tt = 0;
    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 4 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = ((((value.rate * value.quantity) - (value.discount / 100 * (value.quantity * value.rate))) + ff));
      });
    }
    else {
      this.items.forEach(function (value) {
        ff = ((((Number(value.purchase_rate) * value.quantity) - (value.discount / 100 * (value.quantity * Number(value.purchase_rate)))) + ff));
      });
    }
    this.total_taxable_amount = ff;
    return ff;
  }
  total() {
    let ff = 0;
    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = value.sales_prices + ff;
        
      });
    }
    else {
      this.items.forEach(function (value) {
        ff = value.purchase_prices + ff;
      });
    }
    this.total_amount = ff;
    this.subTotal = ff;

    return ff;
  }

  total_cess() {
    let ff = 0;

    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 6 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = (value.cess_tax + ff);
      });
    }
    else {
      this.items.forEach(function (value) {
        ff = (value.cessp + ff);
      });
    }
    this.total_cess_rate = ff
    return ff;
  }

  calculateGst() {
    console.log("company gst", this.company_gst);

    if (this.company_gst == null) {
      this.noTax = false

    } else if (this.company_gst == "") {
      this.noTax = false
    }
    if (this.company_gst) {
      this.company_gst = this.company_gst.slice(0, 2)
      this.noTax = true
    }
    console.log("party gst", this.placeOf);

    if (this.placeOf == this.company_gst) {
      if (this.company_gst !== null) {

        this.cgst = this.totaltax / 2
        this.sgst = this.totaltax / 2
        this.igst = 0

      } else {
        this.cgst = 0
        this.sgst = 0
        this.igst = 0
        // this.igst = this.totaltax
      }
    }
    if (this.placeOf !== this.company_gst) {
      console.log(this.placeOf, "not equal");

      if (this.company_gst !== null) {
        this.igst = this.totaltax
        this.cgst = 0
        this.sgst = 0
      }
      else {
        this.cgst = 0
        this.sgst = 0
        this.igst = 0
      }
    }
  }
  calculateTax() {
    let ff = 0;
    if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 4 || this.invoice_type == 7) {
      this.items.forEach(function (value) {
        ff = value.sales_tax + ff;
      });
    }
    else {
      // console.log('total cal for pur');
      this.items.forEach(function (value) {
        ff = value.purchase_tax + ff;
      });
    }
    this.totaltax = ff;
    // console.log("dsfads", ff)
    return ff;

  }
  putinarray() {

    for (let i of this.items) {
      console.log("mmmmaaaaa", this.items);

      if (this.invoice_type == 1 || this.invoice_type == 3 || this.invoice_type == 5 || this.invoice_type == 4 || this.invoice_type == 7) {
        if (i.Gst_tax_rate == -1) {

          console.log("put if running",this.items);

          this.finalItem.push({
            unit: i.units.id,
            unit_type: i.abc.type,
            items: i.id,
            quantity: i.quantity,
            discount: Number(i.discount),
            rate: Number(i.rate),
            total_amount: i.sales_prices,
            tax_percent: i.Gst_tax_rate,
            tax_amount: i.sales_tax,
            cess: i.cess_tax_rate,
            cess_amount: i.cess,
            tax_rate_id: i.tax_rate_id,
            cess_rate_id: i.cess_tax_rate_id
          });
        }
        else {
          console.log("put else running");

          this.finalItem.push({
            unit: i.abc.id,
            unit_type: i.abc.type,
            items: i.id,
            quantity: i.quantity,
            discount: Number(i.discount),
            rate: Number(i.rate),
            total_amount: i.sales_prices,
            tax_percent: i.Gst_tax_rate,
            tax_amount: i.sales_tax,
            cess: i.cess_tax_rate,
            cess_amount: i.cess,
            tax_rate_id: i.tax_rate_id,
            cess_rate_id: i.cess_tax_rate_id
          });

        }
      }
      else {
        this.finalItem.push({
          unit: i.abc.id,
          unit_type: i.abc.type,
          items: i.id,
          quantity: i.quantity,
          discount: Number(i.discount),
          rate: Number(i.purchase_rate),
          total_amount: i.purchase_prices,
          tax_percent: i.Gst_tax_rate,
          tax_amount: i.purchase_tax,
          cess: i.cess_tax_rate,
          tax_rate_id: i.tax_rate_id,
          cess_amount: i.cessp,
          cess_tax_rate_id: i.cess_tax_rate_id
        });
      }
    } return this.finalItem
  }
  refreshInvoice() {
    window.location.assign('/sales-invoice');
    console.log("func calling refresh");
  }
  editInvoiceNo() {

    console.log("edit");
    this.dateChange()
    this.modal.dismiss();


  }
  sendSMS() {
    let header = this.api.getHeader();
    this.api.sendRemainder(this.invoiceID, header).subscribe((response: any) => {
      console.log(response, "pos data response");
    })
  }

  saveInvoice() {
    console.log("qqqqqq", this.items);

    this.putinarray()
    this.invoice_model.Igst = this.igst
    this.invoice_model.cgst = this.cgst
    this.invoice_model.sgst = this.sgst
    this.invoice_model.taxable_amount = this.total_taxable_amount
    this.invoice_model.total_amount = this.subTotal
    this.invoice_model.party = this.party_details.id
    this.invoice_model.items = this.finalItem
    this.invoice_model.receivable = this.finalAmount;
    this.invoice_model.partial_paid = this.partialPAid
    this.invoice_model.discount = this.invoice_model.discountTotal

    console.log(this.invoice_model, "invoice");
    if (this.finalItem.sales_tax) {
      this.invoice_model.items.tax_amount = this.finalItem.sales_tax
    }
    if (this.finalItem.purchase_tax) {
      this.invoice_model.items.tax_amount = this.finalItem.purchase_tax
    }
    if (this.finalItem.cess) {
      this.invoice_model.items.cess = this.finalItem.cess
    }
    if (this.items.tax_percent == -1) {
      console.log("expmted received in save",);
      this.invoice_model.items.tax_percent = -1
    }
    if (this.finalItem.cessp) {
      this.invoice_model.items.cess = this.finalItem.cessp
    }

    if (this.invoice_model.invoice_no && this.invoice_model.items.length && this.invoice_model.party) {
      console.log("valid form");

      this.submit = true
    } else {
      this.submit = false
      console.log("qwe INvalid form");
      // alert(this.translate.instant('MESSAGE.PLEASE ENTER REQUIRED FEILD'))

      if (this.submit == false) {
        if (!this.invoice_model.items.length) {
          console.log(this.invoice_model, "invoice");
          alert(this.translate.instant('MESSAGE.PLEASE ADD ITEMS'))
        }
        else if (!this.invoice_model.invoice_no) {
          console.log(this.invoice_model, "invoice");
          alert(this.translate.instant('MESSAGE.PLEASE ENTER INVOICE NUMBER'))
        }
      }

    }
    if (this.submit == true) {

      let companyId = this.api.getCompanyId()
      this.invoice_model.company_name = companyId;

      let header = this.api.getHeader();

      this.invoice_model.extra_charges_lst = this.exp1
      // this.invoice_model.extra_fields = this.extraF
      // console.log(this.extraF,"extraaaaaaaaaa");
      this.invoice_model.cess=this.total_cess_rate
      console.log("this.invoice_model", this.invoice_model);
      console.log(this.invSett.extra_fields, 'invSett.extrafields');
      if (this.invoice_model.invoice_type == 1) {
        if (this.invoice_model.extra_fields.length != 0) {
          const extraF = this.invSett.extra_fields.map(({ extra_fields, extra_fieldsValue }) => ({ [extra_fields]: extra_fieldsValue }));
          console.log(extraF, 'extra fields');

          this.invoice_model.extra_fields = extraF
          console.log(this.invoice_model, 'invoice model create');
        }
        else {
          this.invoice_model.extra_fields = []
        }
          }
          this.api.createInvoice(this.invoice_model, header).subscribe(async (response: any) => {
            console.log("status of invioce", response);

            if (response.status_code == 0) {
              //alert(response["message"])
              this.finalItem = []
              const toast = await this.toastController.create({
                message: response["message"],
                duration: 3000,
                color: "warning"
              });
              toast.present();
            }
            if (response.status_code == 3) {
              if (this.invoice_type == 1) {
                const toast = await this.toastController.create({
                  message: this.translate.instant("MESSAGE.SALES INVOICE CREATED SUCCESSFULLY"),
                  duration: 3000,
                  color: "warning"
                });
                toast.present();
              }
              if (this.invoice_type == 2) {
                const toast = await this.toastController.create({
                  message: this.translate.instant("MESSAGE.PURCHASE INVOICE CREATED SUCCESSFULLY"),
                  duration: 3000,
                  color: "warning"
                });
                toast.present();
              }
              if (this.invoice_type == 4) {
                const toast = await this.toastController.create({
                  message: this.translate.instant("MESSAGE.PURCHASE RETURN CREATED SUCCESSFULLY"),
                  duration: 3000,
                  color: "warning"
                });
                toast.present();
              }
              if (this.invoice_type == 3) {
                const toast = await this.toastController.create({
                  message: this.translate.instant("MESSAGE.SALES RETURN CREATED SUCCESSFULLY"),
                  duration: 3000,
                  color: "warning"
                });
                toast.present();
              }
              if (this.invoice_type == 5) {
                const toast = await this.toastController.create({
                  message: this.translate.instant("MESSAGE.QUOTATION CREATED SUCCESSFULLY"),
                  duration: 3000,
                  color: "warning"
                });
                toast.present();
              }
              if (this.invoice_type == 6) {
                const toast = await this.toastController.create({
                  message: this.translate.instant("MESSAGE.CHALLAN CREATED SUCCESSFULLY"),
                  duration: 3000,
                  color: "warning"
                });
                toast.present();
              }
              if (this.invoice_type == 7) {
                const toast = await this.toastController.create({
                  message: this.translate.instant("MESSAGE.PROFORMA INVOICE CREATED SUCCESSFULLY"),
                  duration: 3000,
                  color: "warning"
                });
                toast.present();
              }
              console.log(response.data);


              this.invoiceD = response.data

              this.downloadUrl = 'https://api.esarwa.com/api/create_pdf/' + response["data"] + '/';

              this.invoiceID = response.data
              console.log("invoiceID", this.invoiceID);
              // if (response.data != null) {
              //   if (this.einvoice) {

              //     this.createEInvoice(this.invoiceID)
              //   }
              // }
      }

      });
    }

  }
  createEInvoice(data: any) {
    let company_id = this.api.getCompanyId()
    this.api.geteinvoice({ "invoice_id": this.invoiceID, "company_id": company_id }).subscribe((response: any) => {
      console.log(response, "e invoice result");
      if (response.status == 200) {
        this.downloadEinvoiceButton = true
        // this.downloadEinvoicePDF(data);

        if (this.eWayBill == true) {
          if (this.vehicleDetails == true) {
            this.vehicleSubmitted.invoice = data
            this.api.submitTransportDetails(this.vehicleSubmitted).subscribe((response: any) => {
              //submited transport details
              if (response.status == 200) {
                this.createEwayBill(data);
              }
            })

          }
        }

      }
    })
  }

  segmentChanged(event: any) {
    this.selectSegment = event.target.value;

    console.log(event.detail.value);
    console.log(this.selectSegment, "selected segment");
  }
  ngAfterViewInit() {
    // this.selectSegment = 'a';

  }
  onSegmentChange(event) {
    console.log(event.detail.value);
  }
  dismis() {
    this.modal.dismiss();
  }
  modal1() {

  }
  ewaySubmit(d: any) {
    this.vehicleDetails = true
    console.log("submit eway", d);
    this.vehicleSubmitted = d
    this.modal.dismiss()
  }
  createEwayBill(data: any) {
    this.api.createEwb({ invoice_id: data }).subscribe((response: any) => {
      console.log("create eway bill response", response);
      if (response.status == 200) {
        console.log(response.data, "eway bill created");
        this.ewaybillDownload = true
        this.get_ewb(data);
      } else {
        this.toast.warning({ detail: this.translate.instant("MESSAGE.FAILED"), summary: response.msg })
        console.log(response.msg);
      }
    })
  }
  get_ewb(data) {
    this.api.get_ewb({ invoice_id: data }).subscribe((response: any) => {
      console.log("ewaybill", response);
      if (response.status == 200) {
        this.e = response.data;
        // this.ebarcode = this.e.ewbNo + "/" + this.e.userGstin + "/" + this.e.ewayBillDate;
      }
    })
  }
  eway: any = {
    // "invoice":1643,
    "vehicle_no": "",
    "vehicle_type": "R",
    "trans_mode": "1",
    "distance": 0
  }
  vehicle_type: any = [{ id: "0", name: "Regular" }, { id: "1", name: "Over-Dimensional Cargo" }]
  transport_type: any = [{ id: 1, name: "Road" }, { id: 2, name: "Rail" }, { id: 3, name: "Air" }, { id: 4, name: "Ship" }]

  collectPayment() {
    this.api.collectPaymentPos(this.invoiceD).subscribe((response: any) => {
      console.log(response, "pos data response");
      this.merchanTrans_id = response.body.merchantTransactionId

      this.statusbutton = true
      this.progressWheel = true
    })
  }
  getPayStatus() {
    this.api.getPaymentStatus(this.invoiceD, this.merchanTrans_id).subscribe((response: any) => {
      console.log(response, "Staus REsponse");
      this.payentStatusPOS = response
      if (response.result.resultStatus === 'FAIL') {
        alert(this.translate.instant('MESSAGE.PAYMENT FAILED'))
        this.resendbutton = true
      } else if (response.result.resultStatus === 'PENDING') {
        alert(this.translate.instant('MESSAGE.PLEASE CHECK EDC MACHINE'))
      }
      else {
        alert(this.translate.instant('MESSAGE.PAYMENT SUCCESSFUL'))
        this.paymentDone = true
        this.progressWheel = false
      }
    })
  }
  addAnotherCharges() {
    this.addCharge = true
    let data = {
      extra_charges: "",
      extra_amt: 0,
    }
    this.exp1.push(data);

  }
  total1() {
    let ff = 0;
    this.exp1.forEach(function (value) {
      ff = value.extra_amt + ff;
    });
    this.subTotal = ff;
    return ff;
  }
  deleteRow(i: number) {
    this.exp1.splice(i, 1);
    this.calculation()
  }
  deleteRow1(i: number) {
    console.log("delete");

    this.extraF.splice(i, 1)
  }
  Change() {
    if (this.invoice_model.checked) {
      this.partialPAid = 1
    } else {
      this.partialPAid = 0
    }
    console.log(this.partialPAid);
  }

  einvoice(d: any) {
    console.log(d, "invoice");
    if (this.eInvoice == true) {
    }
  }
  async ewayBill1() {
    console.log("show", this.eWayBill);

    if (this.eWayBill == true) {
      const modal = await this.modal.create({
        component: EWayPage,

        breakpoints: [0, 0.3, 0.5, 1],
        initialBreakpoint: 0.8
      });
      modal.onDidDismiss()
        .then((data) => {
          console.log("closedata", data);
          this.createEInvoice(data.data);
        });
      return await modal.present();
    }
  }


  // ClickNewRow() {

  //   this.addF=true
  //   let data={
  //     extra_fields:'',
  //     addField:''
  //   }
  //   this.extraF.push(data);
  //   console.log("ok", this.addF);
  // }
  // invPrefix() {
  //   if (this.invoice_model.isChecked3 == true) {
  //     this.prefix = true;
  //   } else {
  //     this.prefix = false;
  //   }
  // }
  supply() {
    this.api.receivedState().subscribe((response: any[]) => {
      this.place_of_supply = response["data"]
      console.log("state", this.place_of_supply);
      this.place = this.place_of_supply
      if (this.place) {
        this.placeOf = this.party_details.gst_compare
        this.place.place_of_supply = Number(this.placeOf)
        if (this.place.place_of_supply < 10) {
          this.placeOf = "0" + this.invoice_model.place_of_supply.toString()
          console.log(this.placeOf, "ppppppp");
        }
        else {
          this.placeOf = this.invoice_model.place_of_supply.toString()
          console.log(this.placeOf, "else");
        }
      }
      this.calculation();
      this.calculateTax();
      this.calculateGst();
    });
  }
  async setting() {
    console.log("click");
    const modal = await this.modal.create({
      component: InvoiceSettingPage,

      breakpoints: [0, 0.3, 0.5, 1],
      initialBreakpoint: 0.8
    });
    modal.onDidDismiss()
      .then(async (data) => {
        console.log("closedata");
        this.invoice_head();
        const user = data.data; // Here's your selected user!
        const toast = await this.toastController.create({
          message: "Invoice setting updated successfully",
          duration: 2000,
          color: "warning"
        });
        toast.present();
      });
    return await modal.present();
  }
}
