import { InvoiceSettingPage } from './../invoice-setting/invoice-setting.page';
import { PartyListPage } from './../party-list/party-list.page';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { InvoiceBetaPageRoutingModule } from './invoice-beta-routing.module';
import { ShowItemPage } from "../show-item/show-item.page";
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InvoiceBetaPageRoutingModule,
    TranslateModule
  ],
  declarations: [ShowItemPage,PartyListPage,InvoiceSettingPage],
})
export class InvoiceBetaPageModule {}
